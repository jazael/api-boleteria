CREATE PROCEDURE spc_Evidenciadmotivo @red_Id numeric(18,0) AS SELECT red_Id,red_motivo FROM REAtbevidenciadet where red_Id=@red_Id
go

