CREATE Procedure spc_apwrRecomendacionAsigUsu  
--@rri_id numeric(18,0),  
--@usr_codigo smallint,
--@rec_recomendacion  varchar(max)
--AS
--IF(@rec_recomendacion ='')
--Begin
--SELECT rec.rec_id, rin.rri_Id, emp_codigo, rin.rri_ninforme, rec.rec_fechaini, rec.rec_fechafin, rec.rec_recomendacion 
--FROM RRItbrecomendacion AS rec INNER JOIN RItbinforme AS rin ON rec.rri_id = rin.rri_Id
--INNER JOIN RRDtbserres AS res on rec.rec_id=res.rec_id
--WHERE (rec.rec_activado = 1) and rin.rri_id=@rri_id  and emp_codigo=(Select emp_codigo from wftbusuario where usr_codigo=@usr_codigo) ORDER BY rec.rec_fechaini
--END

--IF(@rec_recomendacion <>'')
--Begin
--SELECT rec.rec_id, rin.rri_Id, rin.rri_ninforme, rec.rec_fechaini, rec.rec_fechafin, rec.rec_recomendacion 
--FROM RRItbrecomendacion AS rec INNER JOIN RItbinforme AS rin ON rec.rri_id = rin.rri_Id
--INNER JOIN RRDtbserres AS res on rec.rec_id=res.rec_id
--WHERE rec.rec_recomendacion Like '%'+@rec_recomendacion+'%' and (rec.rec_activado = 1) and rin.rri_id=@rri_id 
--and emp_codigo=(Select emp_codigo from wftbusuario where usr_codigo=@usr_codigo) ORDER BY rec.rec_fechaini
--END

@tipo char(1),
@buscarpor varchar(80),
@usr_codigo smallint
AS
if(@buscarpor=' ')
Begin
Set @buscarpor=''
End

IF((@buscarpor<>'') and (@tipo=1))
Begin
SELECT rec.rec_id, rin.rri_Id, emp_codigo, rin.rri_ninforme, rec.rec_fechaini, rec.rec_fechafin, rec.rec_recomendacion 
FROM RRItbrecomendacion AS rec INNER JOIN RItbinforme AS rin ON rec.rri_id = rin.rri_Id
INNER JOIN RRDtbserres AS res on rec.rec_id=res.rec_id
WHERE (rec.rec_activado = 1) and rin.rri_ninforme Like '%'+@buscarpor+'%' 
and emp_codigo=(Select emp_codigo from wftbusuario where usr_codigo=@usr_codigo) ORDER BY rec.rec_fechaini
END

IF((@buscarpor='') and (@tipo=1))
Begin
SELECT top(20)rec.rec_id, rin.rri_Id, rin.rri_ninforme, rec.rec_fechaini, rec.rec_fechafin, rec.rec_recomendacion 
FROM RRItbrecomendacion AS rec INNER JOIN RItbinforme AS rin ON rec.rri_id = rin.rri_Id
INNER JOIN RRDtbserres AS res on rec.rec_id=res.rec_id
WHERE  rin.rri_ninforme Like '%'+@buscarpor+'%' and (rec.rec_activado = 1) 
and emp_codigo=(Select emp_codigo from wftbusuario where usr_codigo=@usr_codigo) ORDER BY rec.rec_fechaini
END

IF((@buscarpor<>'') and (@tipo=2))
Begin
SELECT rec.rec_id, rin.rri_Id, emp_codigo, rin.rri_ninforme, rec.rec_fechaini, rec.rec_fechafin, rec.rec_recomendacion 
FROM RRItbrecomendacion AS rec INNER JOIN RItbinforme AS rin ON rec.rri_id = rin.rri_Id
INNER JOIN RRDtbserres AS res on rec.rec_id=res.rec_id
WHERE (rec.rec_activado = 1) and rri_alcance Like '%'+@buscarpor+'%' 
and emp_codigo=(Select emp_codigo from wftbusuario where usr_codigo=@usr_codigo) ORDER BY rec.rec_fechaini
END

IF((@buscarpor='') and (@tipo=2))
Begin
SELECT top(20)rec.rec_id, rin.rri_Id, rin.rri_ninforme, rec.rec_fechaini, rec.rec_fechafin, rec.rec_recomendacion 
FROM RRItbrecomendacion AS rec INNER JOIN RItbinforme AS rin ON rec.rri_id = rin.rri_Id
INNER JOIN RRDtbserres AS res on rec.rec_id=res.rec_id
WHERE  (rec.rec_activado = 1) and rri_alcance Like '%'+@buscarpor+'%'
and emp_codigo=(Select emp_codigo from wftbusuario where usr_codigo=@usr_codigo) ORDER BY rec.rec_fechaini
END

IF((@buscarpor<>'') and (@tipo=3))
Begin
SELECT rec.rec_id, rin.rri_Id, emp_codigo, rin.rri_ninforme, rec.rec_fechaini, rec.rec_fechafin, rec.rec_recomendacion 
FROM RRItbrecomendacion AS rec INNER JOIN RItbinforme AS rin ON rec.rri_id = rin.rri_Id
INNER JOIN RRDtbserres AS res on rec.rec_id=res.rec_id
WHERE (rec.rec_activado = 1) and rec.rec_recomendacion  Like '%'+@buscarpor+'%' 
and emp_codigo=(Select emp_codigo from wftbusuario where usr_codigo=@usr_codigo) ORDER BY rec.rec_fechaini
END

IF((@buscarpor='') and (@tipo=3))
Begin
SELECT top(20)rec.rec_id, rin.rri_Id, rin.rri_ninforme, rec.rec_fechaini, rec.rec_fechafin, rec.rec_recomendacion 
FROM RRItbrecomendacion AS rec INNER JOIN RItbinforme AS rin ON rec.rri_id = rin.rri_Id
INNER JOIN RRDtbserres AS res on rec.rec_id=res.rec_id
WHERE  (rec.rec_activado = 1) and rec.rec_recomendacion  Like '%'+@buscarpor+'%'
and emp_codigo=(Select emp_codigo from wftbusuario where usr_codigo=@usr_codigo) ORDER BY rec.rec_fechaini
END
go

