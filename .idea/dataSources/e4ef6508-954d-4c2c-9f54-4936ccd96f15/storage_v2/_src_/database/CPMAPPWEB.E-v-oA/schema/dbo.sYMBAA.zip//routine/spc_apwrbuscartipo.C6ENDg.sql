CREATE PROCEDURE spc_apwrbuscartipo
	@buscarpor tinyint,
	@descripcion varchar(80)
AS

--if(@buscarpor=0)
--begin
--declare @descripcion varchar(80)
--set @descripcion='5-DPM-AI-0038-201'
/*SELECT top(10) inf.rri_Id, inf.emi_id, emi.emi_emitida,inf.rri_ninforme, inf.rri_faprobacion, inf.rri_alcance/*, inf.rri_informe*/, inf.rri_activado 
FROM RItbinforme AS inf INNER JOIN REtbemitido AS emi ON emi.emi_id = inf.emi_id 
ORDER BY inf.rri_faprobacion DESC*/
--end

if(@buscarpor=1)
begin
--declare @descripcion varchar(80)
--set @descripcion='5-DPM-AI-0038-201'
SELECT inf.rri_Id, inf.emi_id, emi.emi_emitida,inf.rri_ninforme, inf.rri_faprobacion, inf.rri_alcance, /*inf.rri_informe, */inf.rri_activado 
FROM RItbinforme AS inf INNER JOIN REtbemitido AS emi ON emi.emi_id = inf.emi_id 
where rri_ninforme Like '%'+@descripcion+'%'  ORDER BY inf.rri_faprobacion DESC
end

if(@buscarpor=2)
begin
SELECT inf.rri_Id, inf.emi_id, emi.emi_emitida,inf.rri_ninforme, inf.rri_faprobacion, inf.rri_alcance/*, inf.rri_informe*/, inf.rri_activado 
FROM RItbinforme AS inf INNER JOIN REtbemitido AS emi ON emi.emi_id = inf.emi_id
where rri_alcance Like '%'+@descripcion+'%' ORDER BY inf.rri_faprobacion DESC
end
go

