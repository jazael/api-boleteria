create procedure spi_AsigIp
@dep_codigo smallint,
@reg_fecha smalldatetime,
@reg_asignado nvarchar(100),
@reg_ip nchar(15),
@reg_mac nchar(17),
@reg_host nchar(50),
@reg_ubica nchar(150),
@reg_obser nchar(200),
@reg_inter bit,
@usr_codigo smallint

as 
declare @mensaje as nvarchar(50)
if not exists(select reg_ip from CIPRegistro where reg_ip=@reg_ip and reg_activado=1)
begin
	if not exists (select reg_mac from CIPRegistro where reg_mac=@reg_mac and reg_activado=1)
	begin
	insert CIPRegistro(dep_codigo,reg_fecha,reg_asignado,reg_ip,reg_mac,reg_host,reg_ubica,reg_obser,reg_inter,usr_codigo,reg_activado)
		values(@dep_codigo,@reg_fecha,@reg_asignado,@reg_ip,@reg_mac,@reg_host,@reg_ubica,@reg_obser,@reg_inter,@usr_codigo,1)
		set @mensaje='Registro Guardado con Exito'
	end
	else
	begin
	set @mensaje='Ya se encuantra registrada la MAC ingresada'
	end
end
else
begin
set @mensaje='Ya se encuantra registrada la IP ingresada'
end
select @mensaje as mensaje
go

