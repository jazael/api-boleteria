create procedure spr_DHSregsol
@reg_cedula	varchar(10)
as
declare @codigo as int
set @codigo =(select max(sol_codpmt) as valor from DHSRegistro where sol_cedula=@reg_cedula and sol_activado=1 and sol_estado=1)

select sol_codpro,sol_nombre,sol_apellido,sol_email,sol_telefono,sol_cedulaB,sol_nombreB,sol_apellidoB,sol_detalleR 
		from DHSRegistro where sol_codpmt=@codigo

