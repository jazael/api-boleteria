
create  procedure spu_regperf
@per_id	numeric(18, 0),
@per_bases	image	
as

update CMOtbperfiles set
per_bases=@per_bases
where per_id=@per_id

go

