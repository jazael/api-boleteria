CREATE Procedure spd_RARActividad
@rar_Id numeric(18,0)
AS
Delete dbo.RARTBActividad where rar_Id=@rar_Id --and rat_id=@rat_Id --and rri_id=@rri_id and rec_id=@rec_id and usr_codigo=@usr_codigo

