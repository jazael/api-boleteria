create procedure [dbo].[spi_opcasig]
@usr_codigo smallint,
@opt_codigo tinyint,
@opu_activado bit,
@cod_usr smallint,
@host nchar(20),
@adress nchar(20)
as
if exists (select opt_codigo from wftbopcion_usuario where usr_codigo=@usr_codigo and opt_codigo=@opt_codigo ) 
begin
		update wftbopcion_usuario set 
		opu_activado=@opu_activado
		where usr_codigo=@usr_codigo and opt_codigo=@opt_codigo
end
else
begin
		insert wftbopcion_usuario(usr_codigo,opt_codigo,opu_activado)
							values(@usr_codigo,@opt_codigo,@opu_activado)

end
exec spi_auditoriaP @cod_usr,'spi_opcasig','Permisos',@host ,@adress

go

