CREATE PROCEDURE spi_RARActividad
@rri_id NUMERIC (18),
@rec_id NUMERIC (18),
@usr_codigo SMALLINT,
@rar_fechaini DATETIME,
@rar_fechafin DATETIME,
@rar_estrategia Varchar(max),
@rar_actividad VARCHAR(MAX)

AS
Declare @rar_Id NUMERIC (18,0)
Select @rar_Id =isnull(max(rar_Id),0)+1 from dbo.RARTBActividad
Insert Into dbo.RARTBActividad(rar_Id,rri_id,rec_id,usr_codigo,rar_fechaingreso,rar_fechaini,rar_fechafin,rar_estrategia,rar_actividad,rar_estado,rar_activado,rar_terminada,rar_motivo)
Values (@rar_Id,@rri_id,@rec_id,@usr_codigo,getdate(),@rar_fechaini,@rar_fechafin,@rar_estrategia,@rar_actividad,'0','1','0','')

--Declare @rat_Id numeric(18,0)
--Declare @rat_activado bit
--Declare RARTBActividadTemp cursor for SELECT rat_Id,rri_id,rec_id,usr_codigo,rat_fechaini,rat_fechafin,rat_actividad,rat_activado 
--from RARTBActividadTemp Where usr_codigo=@usr_codigo and rri_id=@rri_id and rec_id=@rec_id
--OPEN RARTBActividadTemp
--FETCH NEXT FROM RARTBActividadTemp
--INTO @rat_Id,@rri_id,@rec_id,@usr_codigo,@rar_fechaini,@rar_fechafin,@rar_actividad,@rat_activado

--WHILE @@FETCH_STATUS = 0
--BEGIN
--Select @rar_Id =isnull(max(rar_Id),0)+1 from dbo.RARTBActividad
--Insert Into dbo.RARTBActividad(rar_Id,rri_id,rec_id,usr_codigo,rar_fechaingreso,rar_fechaini,rar_fechafin,rar_actividad,rar_activado)
--Values (@rar_Id,@rri_id,@rec_id,@usr_codigo,getdate(),@rar_fechaini,@rar_fechafin,@rar_actividad,'1')

--delete RARTBActividadTemp where rri_id=@rri_id and rat_Id=@rat_Id

--FETCH NEXT FROM RRDtbserdirtemp
--INTO @rat_Id,@rri_id,@rec_id,@usr_codigo,@rar_fechaini,@rar_fechafin,@rar_actividad,@rat_activado
--END   
--CLOSE RARTBActividadTemp
--DEALLOCATE RARTBActividadTemp
go

