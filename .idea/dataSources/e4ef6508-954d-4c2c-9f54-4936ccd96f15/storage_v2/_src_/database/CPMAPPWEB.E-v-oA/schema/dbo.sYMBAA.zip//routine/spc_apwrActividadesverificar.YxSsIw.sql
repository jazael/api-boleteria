CREATE PROCEDURE spc_apwrActividadesverificar
				
				 
@tipo char(1),
@buscarpor varchar(80)  
AS
if(@buscarpor=' ')
Begin
Set @buscarpor=''
End

IF((@buscarpor<>'') and (@tipo=1))
BEGIN
SELECT  Distinct top(20) rri.rri_id,rec.rec_id/*,usr.usr_codigo,emp_apellido+' '+emp_nombre AS Servidor*/,rri.rri_ninforme,rri.rri_alcance,rec.rec_recomendacion
FROM RItbinforme AS rri Inner Join RRItbrecomendacion AS rec ON rri.rri_Id=rec.rri_id
Inner Join RARTBActividad rar ON rar.rec_id=rec.rec_id 
Inner Join wftbusuario AS usr ON usr.usr_codigo=rar.usr_codigo
--Inner Join CPMRRHH.dbo.rhtbempleado AS emp ON emp.emp_codigo=usr.emp_codigo 
where rri.rri_activado=1 and rec.rec_activado=1 and rar.rar_activado=1 and rri.rri_ninforme Like '%'+@buscarpor+'%' order by 3,5
END

IF((@buscarpor='') and (@tipo=1))
BEGIN
SELECT  Distinct rri.rri_id,rec.rec_id/*,usr.usr_codigo,emp_apellido+' '+emp_nombre AS Servidor*/,rri.rri_ninforme,rri.rri_alcance, rec.rec_recomendacion
FROM RItbinforme AS rri Inner Join RRItbrecomendacion AS rec ON rri.rri_Id=rec.rri_id
Inner Join RARTBActividad rar ON rar.rec_id=rec.rec_id 
Inner Join wftbusuario AS usr ON usr.usr_codigo=rar.usr_codigo
--Inner Join CPMRRHH.dbo.rhtbempleado AS emp ON emp.emp_codigo=usr.emp_codigo 
where rri.rri_activado=1 and rec.rec_activado=1 and rar.rar_activado=1 and rri.rri_ninforme Like '%'+@buscarpor+'%' order by 3,5
END

IF((@buscarpor<>'') and (@tipo=2))
BEGIN
SELECT  Distinct top(20) rri.rri_id,rec.rec_id/*,usr.usr_codigo,emp_apellido+' '+emp_nombre AS Servidor*/,rri.rri_ninforme,rri.rri_alcance,rec.rec_recomendacion
FROM RItbinforme AS rri Inner Join RRItbrecomendacion AS rec ON rri.rri_Id=rec.rri_id
Inner Join RARTBActividad rar ON rar.rec_id=rec.rec_id 
Inner Join wftbusuario AS usr ON usr.usr_codigo=rar.usr_codigo
--Inner Join CPMRRHH.dbo.rhtbempleado AS emp ON emp.emp_codigo=usr.emp_codigo 
where rri.rri_activado=1 and rec.rec_activado=1 and rar.rar_activado=1 and rri_alcance Like '%'+@buscarpor+'%' order by 3,5
END

IF((@buscarpor='') and (@tipo=2))
BEGIN
SELECT  Distinct rri.rri_id,rec.rec_id/*,usr.usr_codigo,emp_apellido+' '+emp_nombre AS Servidor*/,rri.rri_ninforme,rri.rri_alcance,rec.rec_recomendacion
FROM RItbinforme AS rri Inner Join RRItbrecomendacion AS rec ON rri.rri_Id=rec.rri_id
Inner Join RARTBActividad rar ON rar.rec_id=rec.rec_id 
Inner Join wftbusuario AS usr ON usr.usr_codigo=rar.usr_codigo
--Inner Join CPMRRHH.dbo.rhtbempleado AS emp ON emp.emp_codigo=usr.emp_codigo 
where rri.rri_activado=1 and rec.rec_activado=1 and rar.rar_activado=1 and rri_alcance Like '%'+@buscarpor+'%' order by 3,5
END

IF((@buscarpor<>'') and (@tipo=3))
BEGIN
SELECT  Distinct top(20) rri.rri_id,rec.rec_id/*,usr.usr_codigo,emp_apellido+' '+emp_nombre AS Servidor*/,rri.rri_ninforme,rri.rri_alcance,rec.rec_recomendacion
FROM RItbinforme AS rri Inner Join RRItbrecomendacion AS rec ON rri.rri_Id=rec.rri_id
Inner Join RARTBActividad rar ON rar.rec_id=rec.rec_id 
Inner Join wftbusuario AS usr ON usr.usr_codigo=rar.usr_codigo
--Inner Join CPMRRHH.dbo.rhtbempleado AS emp ON emp.emp_codigo=usr.emp_codigo 
where rri.rri_activado=1 and rec.rec_activado=1 and rar.rar_activado=1 and (rec.rec_recomendacion Like '%'+@buscarpor+'%') order by 3,5
END

IF((@buscarpor='') and (@tipo=3))
BEGIN
SELECT  Distinct rri.rri_id,rec.rec_id/*,usr.usr_codigo,emp_apellido+' '+emp_nombre AS Servidor*/,rri.rri_ninforme,rri.rri_alcance,rec.rec_recomendacion
FROM RItbinforme AS rri Inner Join RRItbrecomendacion AS rec ON rri.rri_Id=rec.rri_id
Inner Join RARTBActividad rar ON rar.rec_id=rec.rec_id 
Inner Join wftbusuario AS usr ON usr.usr_codigo=rar.usr_codigo
--Inner Join CPMRRHH.dbo.rhtbempleado AS emp ON emp.emp_codigo=usr.emp_codigo 
where rri.rri_activado=1 and rec.rec_activado=1 and rar.rar_activado=1 and(rec.rec_recomendacion Like '%'+@buscarpor+'%') order by 3,5
END

--IF((@buscarpor<>'') and (@tipo=4))
--BEGIN
--SELECT  Distinct top(20) rri.rri_id,rec.rec_id,usr.usr_codigo/*,emp_apellido+' '+emp_nombre AS Servidor*/,rri.rri_ninforme,rri.rri_alcance,rec.rec_recomendacion
--FROM RItbinforme AS rri Inner Join RRItbrecomendacion AS rec ON rri.rri_Id=rec.rec_id
--Inner Join RARTBActividad rar ON rar.rec_id=rec.rec_id 
--Inner Join wftbusuario AS usr ON usr.usr_codigo=rar.usr_codigo
----Inner Join CPMRRHH.dbo.rhtbempleado AS emp ON emp.emp_codigo=usr.emp_codigo 
--where rri.rri_activado=1 and rec.rec_activado=1 and rar.rar_activado=1 and (emp_apellido Like '%'+@buscarpor+'%') order by 3,5
--END

--IF((@buscarpor='') and (@tipo=4))
--BEGIN
--SELECT  Distinct rri.rri_id,rec.rec_id,usr.usr_codigo/*,emp_apellido+' '+emp_nombre AS Servidor*/,rri.rri_ninforme,rri.rri_alcance,rec.rec_recomendacion
--FROM RItbinforme AS rri Inner Join RRItbrecomendacion AS rec ON rri.rri_Id=rec.rec_id
--Inner Join RARTBActividad rar ON rar.rec_id=rec.rec_id 
--Inner Join wftbusuario AS usr ON usr.usr_codigo=rar.usr_codigo
----Inner Join CPMRRHH.dbo.rhtbempleado AS emp ON emp.emp_codigo=usr.emp_codigo 
--where rri.rri_activado=1 and rec.rec_activado=1 and rar.rar_activado=1 and(emp_apellido Like '%'+@buscarpor+'%') order by 3,5
--END
go

