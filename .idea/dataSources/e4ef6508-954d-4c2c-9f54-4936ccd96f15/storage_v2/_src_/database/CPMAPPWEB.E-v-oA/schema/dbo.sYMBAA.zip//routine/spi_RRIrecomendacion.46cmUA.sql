CREATE procedure spi_RRIrecomendacion
@rri_id NUMERIC (18,0),
@rec_descripanalisis ntext,
@rec_numrecomendacion Varchar(8),
@rec_fechaini SMALLDATETIME,
@rec_fechafin SMALLDATETIME,
--@rec_recomendacion VARCHAR (MAX)
@rec_recomendacion ntext
As
Declare @rec_id NUMERIC (18,0)
Select @rec_id =isnull(max(rec_id),0)+1 from dbo.RRItbrecomendacion
insert into RRItbrecomendacion(rec_id,rri_id,rec_fecharegistro,rec_descripanalisis,rec_numrecomendacion,rec_fechaini,rec_fechafin,rec_recomendacion ,rec_activado)
Values (@rec_id,@rri_id,GETDATE(),@rec_descripanalisis,@rec_numrecomendacion,@rec_fechaini,@rec_fechafin,@rec_recomendacion,'1')

Declare @car_codigo smallint

declare RRDtbserdirtemp cursor for SELECT rri_id,car_codigo from RRDtbserdirtemp
OPEN RRDtbserdirtemp
FETCH NEXT FROM RRDtbserdirtemp
INTO @rri_id,@car_codigo

WHILE @@FETCH_STATUS = 0
BEGIN
--insert into rrdtbserdir(rec_id,emp_codigo)
insert into rrdtbserdir(rec_id,car_codigo)
Values(@rec_id,@car_codigo)
delete RRDtbserdirtemp where rri_id=@rri_id and car_codigo=@car_codigo
FETCH NEXT FROM RRDtbserdirtemp
INTO @rri_id,@car_codigo
END   
CLOSE RRDtbserdirtemp
DEALLOCATE RRDtbserdirtemp
--------------------------------------
------------------------------------
Declare @emp_codigo smallint
declare RRDtbserrestemp cursor for SELECT rri_id,emp_codigo from RRDtbserrestemp
OPEN RRDtbserrestemp
FETCH NEXT FROM RRDtbserrestemp
INTO @rri_id,@emp_codigo

WHILE @@FETCH_STATUS = 0
BEGIN
insert into rrdtbserres(rec_id,emp_codigo)
Values(@rec_id,@emp_codigo)
delete RRDtbserrestemp where rri_id=@rri_id and emp_codigo=@emp_codigo
FETCH NEXT FROM RRDtbserrestemp
INTO @rri_id,@emp_codigo
END   
CLOSE RRDtbserrestemp
DEALLOCATE RRDtbserrestemp
go

