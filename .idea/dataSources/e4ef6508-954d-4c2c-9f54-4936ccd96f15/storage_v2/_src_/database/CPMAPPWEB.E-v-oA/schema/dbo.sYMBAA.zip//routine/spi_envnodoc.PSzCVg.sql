
CREATE procedure [dbo].[spi_envnodoc]
@tra_id int,
@tra_codigoenv	varchar(30),
@tra_fechaenv	smalldatetime,
@tra_docenv	tinyint,
@tra_enviado	nvarchar(30),
@tra_observa	nvarchar(200)
as

update cdtbtramite set
tra_codigoenv=@tra_codigoenv,
tra_fechaenv=@tra_fechaenv,
tra_docenv=@tra_docenv,
tra_enviado=@tra_enviado,
tra_observa=@tra_observa,
tra_fechafxe=getdate()
where tra_id=@tra_id


go

