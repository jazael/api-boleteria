CREATE procedure [dbo].[spi_conape]
@reg_id	numeric(18, 0),
@ape_acade	bit,
@ape_experi	bit,
@ape_capaci	bit,
@ape_tecnica	bit,
@ape_comenta nvarchar(500)
as
--if not exists( select reg_id from CMOtbapela where reg_id=@reg_id and ape_activado=1)
--			begin	
insert CMOtbapela(reg_id,ape_acade,ape_experi,ape_capaci,ape_tecnica,ape_comenta,tpe_codigo,ape_activado,ape_fecha)
		values(@reg_id,@ape_acade,@ape_experi,@ape_capaci,0,@ape_comenta,1,1,getdate())
		--end


go

