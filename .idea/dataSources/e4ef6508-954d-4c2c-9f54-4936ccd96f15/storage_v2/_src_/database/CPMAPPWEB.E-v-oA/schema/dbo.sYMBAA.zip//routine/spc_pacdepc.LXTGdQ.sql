CREATE procedure [dbo].[spc_pacdepc]
@dep_codigo tinyint,
@pan_anio smallint,
@opcion tinyint
AS
if @opcion=1
begin
SELECT     dbo.RBStbpacanu.pan_id, dbo.RBStbtipcompra.tic_descripcion, dbo.RBStbpacanu.pan_deprod, 
                      dbo.RBStbpacanu.pan_cantidad * dbo.RBStbpacanu.pan_costo AS total
FROM         dbo.RBStbpacanu INNER JOIN
                      dbo.RBStbtipcompra ON dbo.RBStbpacanu.tic_codigo = dbo.RBStbtipcompra.tic_codigo
WHERE     (dbo.RBStbpacanu.pan_activado = 1) AND (dbo.RBStbpacanu.pan_valid = 1) AND (dbo.RBStbpacanu.dep_codigo = @dep_codigo) AND 
                      (dbo.RBStbpacanu.pan_anio = @pan_anio) AND (dbo.RBStbpacanu.pan_costo <= 0)
ORDER BY dbo.RBStbpacanu.codigo_cl_inter
end
else
begin
SELECT     dbo.RBStbpacanu.pan_id, dbo.RBStbpacanu.pan_deprod,dbo.RBStbpacanu.pan_cantidad,dbo.RBStbpacanu.pan_costo, dbo.RBStbpacanu.pan_cantidad * dbo.RBStbpacanu.pan_costo AS total
FROM         dbo.RBStbpacanu INNER JOIN
                      dbo.RBStbpartidas ON dbo.RBStbpacanu.par_codigo = dbo.RBStbpartidas.par_codigo
WHERE     (dbo.RBStbpacanu.pan_activado = 1) AND (dbo.RBStbpacanu.pan_valid = 1) AND (dbo.RBStbpacanu.dep_codigo = @dep_codigo) AND 
                      (dbo.RBStbpacanu.pan_anio = @pan_anio) AND (dbo.RBStbpacanu.pan_costo > 0)
ORDER BY dbo.RBStbpacanu.codigo_cl_inter

end
go

