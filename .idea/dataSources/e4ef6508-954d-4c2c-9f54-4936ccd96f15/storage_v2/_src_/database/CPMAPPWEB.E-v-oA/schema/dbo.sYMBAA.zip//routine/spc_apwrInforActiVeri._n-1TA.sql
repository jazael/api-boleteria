CREATE PROCEDURE spc_apwrInforActiVeri
@usr_codigo smallint
AS
Select distinct rin.rri_Id,rri_ninforme from RItbinforme AS rin inner join RARTBActividad AS rac
on rin.rri_Id=rac.rri_id where rar_estado=1 and usr_codigo=@usr_codigo

