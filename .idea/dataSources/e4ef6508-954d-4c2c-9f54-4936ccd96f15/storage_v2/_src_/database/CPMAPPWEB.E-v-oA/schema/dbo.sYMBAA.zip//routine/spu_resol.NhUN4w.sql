

CREATE  procedure [dbo].[spu_resol]
@res_codigo nvarchar(15),
@res_descripcion nvarchar(1000),
@raz_codigo smallint,
@res_coddoc nvarchar(30),
@pro_codigo smallint,
@res_adjudica nchar(100),
@res_fecha smalldatetime,
@res_activado bit,
@cod_usr smallint,
@host nchar(20),
@adress nchar(20)
as 
update RBStbResolc set 
res_descripcion=@res_descripcion,
raz_codigo=@raz_codigo,
res_adjudica=@res_adjudica,
res_fecha=@res_fecha,
res_activado=@res_activado,
res_coddoc=@res_coddoc,
pro_codigo=@pro_codigo
where res_codigo=@res_codigo and res_activado=1
exec spi_auditoriaP @cod_usr,'spu_resol','Modificación Resolución',@host ,@adress
go

