
CREATE procedure [dbo].[spu_InfIng]
@tra_id int,
@dep_codigo	tinyint,
@tra_tdoc	tinyint,
@tra_fecha	smalldatetime,
@tra_benf	nvarchar(80),
@tra_asunto	nvarchar(500),
@tra_codigo varchar(30)
as

update cdtbtramite set
dep_codigo=@dep_codigo,
tra_tdoc=@tra_tdoc,
tra_fecha=@tra_fecha,
tra_benf=@tra_benf,
tra_asunto=@tra_asunto,
tra_codigo=@tra_codigo
where tra_id=@tra_id


go

