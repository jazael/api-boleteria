create procedure [dbo].[spu_password]
@usr_password varchar(50),
@usr_pass varchar(50),
@cod_usr smallint,
@host nchar(20),
@adress nchar(20)
as
declare @ban as nvarchar(50)
set @ban='Contraseña incorrecta'
if exists(select * from wftbusuario where usr_codigo=@cod_usr and usr_password=@usr_password)
begin
update wftbusuario set
usr_password=@usr_pass
where usr_codigo=@cod_usr
set @ban='Contraseña Actualizada'
end
exec spi_auditoriaP @cod_usr,'spu_password','Cambio de Contraseña',@host ,@adress
select @ban as ban
go

