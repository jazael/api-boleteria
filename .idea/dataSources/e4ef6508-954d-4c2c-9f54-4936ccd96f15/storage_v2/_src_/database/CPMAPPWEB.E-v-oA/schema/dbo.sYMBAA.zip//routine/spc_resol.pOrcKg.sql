CREATE  procedure [dbo].[spc_resol]
as 
SELECT     dbo.RBStbResolc.res_codigo, substring(dbo.RBStbResolc.res_descripcion,1,100) as res_descripcion, dbo.RBStbResolc.res_adjudica, dbo.RBStbResolc.res_activado, 
                      dbo.RBStbrazon.raz_descripcion, dbo.RBStbResolc.res_fecha
FROM         dbo.RBStbResolc INNER JOIN
                      dbo.RBStbrazon ON dbo.RBStbResolc.raz_codigo = dbo.RBStbrazon.raz_codigo
WHERE     (dbo.RBStbResolc.res_activado = 1)


go

