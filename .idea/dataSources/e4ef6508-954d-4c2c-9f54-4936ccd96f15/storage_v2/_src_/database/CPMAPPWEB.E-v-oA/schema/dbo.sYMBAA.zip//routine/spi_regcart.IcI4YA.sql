
CREATE PROCEDURE spi_regcart
@car_nombre	nchar(80),
@car_apellido	nchar(80),
@car_cedula	nchar(10),
@car_fecha	smalldatetime,
@car_sangre	nchar(10),
@car_telefono	nchar(80),
@car_carnet	smallint,
@can_codigo smallint
AS

insert CCTcarnet(car_nombre,car_apellido,car_cedula,car_fecha,car_sangre,car_telefono,car_carnet,can_codigo,car_activado)
	Values(@car_nombre,@car_apellido,@car_cedula,@car_fecha,@car_sangre,@car_telefono,@car_carnet,@can_codigo,1)

go

