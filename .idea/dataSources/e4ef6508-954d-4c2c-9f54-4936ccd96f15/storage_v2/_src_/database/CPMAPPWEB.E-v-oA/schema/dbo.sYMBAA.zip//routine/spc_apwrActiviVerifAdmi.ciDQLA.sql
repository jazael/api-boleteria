
CREATE PROCEDURE spc_apwrActiviVerifAdmi
@tipo char(1),
@buscarpor varchar(80),
@usr_codigo smallint
AS


if(@buscarpor=' ')
Begin
Set @buscarpor=''
End
IF((@buscarpor<>'') and (@tipo=1))
BEGIN
SELECT top(20) rar_Id,rir.rri_id,rec.rec_id,usr_codigo,rir.rri_ninforme,rir.rri_alcance,rec.rec_recomendacion, rar_fechaini,rar_fechafin,rar_actividad,rar_estado 
FROM RARTBActividad rar INNER JOIN RItbinforme rir ON rar.rri_id=rir.rri_Id
INNER JOIN RRItbrecomendacion rec ON rar.rec_id=rec.rec_id
where rar_estado=1 and usr_codigo=@usr_codigo and rir.rri_ninforme Like '%'+@buscarpor+'%' order by rar_fechaini,rar_actividad
END

IF((@buscarpor='') and (@tipo=1))
BEGIN
SELECT rar_Id,rir.rri_id,rec.rec_id,usr_codigo,rir.rri_ninforme,rir.rri_alcance,rec.rec_recomendacion, rar_fechaini,rar_fechafin,rar_actividad,rar_estado 
FROM RARTBActividad rar INNER JOIN RItbinforme rir ON rar.rri_id=rir.rri_Id
INNER JOIN RRItbrecomendacion rec ON rar.rec_id=rec.rec_id
where rar_estado=1 and usr_codigo=@usr_codigo and rir.rri_ninforme Like '%'+@buscarpor+'%' order by rar_fechaini,rar_actividad
END

IF((@buscarpor<>'') and (@tipo=2))
BEGIN
SELECT top(20) rar_Id,rir.rri_id,rec.rec_id,usr_codigo,rir.rri_ninforme,rir.rri_alcance,rec.rec_recomendacion, rar_fechaini,rar_fechafin,rar_actividad,rar_estado 
FROM RARTBActividad rar INNER JOIN RItbinforme rir ON rar.rri_id=rir.rri_Id
INNER JOIN RRItbrecomendacion rec ON rar.rec_id=rec.rec_id
where rar_estado=1 and usr_codigo=@usr_codigo and rri_alcance Like '%'+@buscarpor+'%' order by rar_fechaini,rar_actividad
END

IF((@buscarpor='') and (@tipo=2))
BEGIN
SELECT rar_Id,rir.rri_id,rec.rec_id,usr_codigo,rir.rri_ninforme,rir.rri_alcance,rec.rec_recomendacion, rar_fechaini,rar_fechafin,rar_actividad,rar_estado 
FROM RARTBActividad rar INNER JOIN RItbinforme rir ON rar.rri_id=rir.rri_Id
INNER JOIN RRItbrecomendacion rec ON rar.rec_id=rec.rec_id
where rar_estado=1 and usr_codigo=@usr_codigo and rri_alcance Like '%'+@buscarpor+'%' order by rar_fechaini,rar_actividad
END

IF((@buscarpor<>'') and (@tipo=3))
BEGIN
SELECT top(20) rar_Id,rir.rri_id,rec.rec_id,usr_codigo,rir.rri_ninforme,rir.rri_alcance,rec.rec_recomendacion, rar_fechaini,rar_fechafin,rar_actividad,rar_estado 
FROM RARTBActividad rar INNER JOIN RItbinforme rir ON rar.rri_id=rir.rri_Id
INNER JOIN RRItbrecomendacion rec ON rar.rec_id=rec.rec_id
where rar_estado=1 and usr_codigo=@usr_codigo and rec.rec_recomendacion Like '%'+@buscarpor+'%' order by rar_fechaini,rar_actividad
END

IF((@buscarpor='') and (@tipo=3))
BEGIN
SELECT rar_Id,rir.rri_id,rec.rec_id,usr_codigo,rir.rri_ninforme,rir.rri_alcance,rec.rec_recomendacion, rar_fechaini,rar_fechafin,rar_actividad,rar_estado 
FROM RARTBActividad rar INNER JOIN RItbinforme rir ON rar.rri_id=rir.rri_Id
INNER JOIN RRItbrecomendacion rec ON rar.rec_id=rec.rec_id
where rar_estado=1 and usr_codigo=@usr_codigo and rec.rec_recomendacion Like '%'+@buscarpor+'%' order by rar_fechaini,rar_actividad
END
--@rri_id numeric(18,0),
--@rec_id numeric(18,0),
--@usr_codigo smallint
--AS
--SELECT rar_Id,rri_id,rec_id,usr_codigo,rar_fechaini,rar_fechafin,rar_actividad,rar_estado 
--FROM RARTBActividad 
--where rar_estado=1 and rri_id=@rri_id and rec_id=@rec_id and usr_codigo=@usr_codigo order by rar_fechaini,rar_actividad
go

