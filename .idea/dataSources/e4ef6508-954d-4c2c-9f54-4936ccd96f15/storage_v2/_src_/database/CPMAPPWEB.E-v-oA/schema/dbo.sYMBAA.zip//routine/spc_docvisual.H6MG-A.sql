
CREATE procedure [dbo].[spc_docvisual]
@tra_id int,
@dep_codigo tinyint
as
--if @dep_codigo=2
--begin
		SELECT     dbo.CDtbdocumento.doc_codigo, dbo.CDtbtramite.tra_codigo, dbo.CDtbtramite.tra_fecha, dbo.CDtbtramite.tra_benf, 'Recibido' AS estado
		FROM         dbo.CDtbdocumento INNER JOIN
							  dbo.CDtbtramite ON dbo.CDtbdocumento.tra_id = dbo.CDtbtramite.tra_id
		WHERE     (dbo.CDtbdocumento.tra_id = @tra_id) AND (dbo.CDtbdocumento.doc_rec = 0) AND (dbo.CDtbdocumento.doc_activado = 1)
		union all
		SELECT     dbo.CDtbdocumento.doc_codigo, dbo.CDtbtramite.tra_codigoenv as tra_codigo, dbo.CDtbtramite.tra_fechaenv as tra_fecha, dbo.CDtbtramite.tra_enviado as tra_benf, 'Enviado' AS estado
		FROM         dbo.CDtbdocumento INNER JOIN
							  dbo.CDtbtramite ON dbo.CDtbdocumento.tra_id = dbo.CDtbtramite.tra_id
		WHERE     (dbo.CDtbdocumento.tra_id = @tra_id) AND (dbo.CDtbdocumento.doc_rec = 1) AND (dbo.CDtbdocumento.doc_activado = 1)
--end
--else
--begin
--	SELECT     dbo.CDtbdocumento.doc_codigo, dbo.cdtbtramitex.tra_control as tra_codigo, dbo.cdtbtramitex.tra_fecha, dbo.cdtbtramitex.tra_origen as tra_benf, 'Recibido' AS estado
--	FROM         dbo.CDtbdocumento INNER JOIN
--						  dbo.cdtbtramitex ON dbo.CDtbdocumento.tra_id = dbo.cdtbtramitex.tra_exid
--	WHERE     (dbo.CDtbdocumento.tra_id = @tra_id) AND (dbo.CDtbdocumento.doc_activado = 1)
--end
go

