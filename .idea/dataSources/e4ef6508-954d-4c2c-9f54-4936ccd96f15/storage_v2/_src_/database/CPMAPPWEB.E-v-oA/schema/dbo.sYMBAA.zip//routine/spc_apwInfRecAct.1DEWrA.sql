CREATE Procedure spc_apwInfRecAct
@rar_Id numeric(18,0)
AS

SELECT rec.rec_id, rin.rri_Id,rar.rec_id, rri_alcance,rec.rec_recomendacion,rar_actividad
FROM RARTBActividad AS rar inner join RRItbrecomendacion AS rec on rar.rec_id=rec.rec_id
INNER JOIN RItbinforme AS rin ON rec.rri_id = rin.rri_Id WHERE rar.rar_Id=@rar_id and rec_activado=1
go

