

CREATE procedure [dbo].[spi_regdoc]
@tra_codigo	varchar(30),
@tra_fecha	smalldatetime,
@tra_tdoc	tinyint,
@dep_codigo	tinyint,
@tra_benf	nvarchar(80),
@tra_asunto	nvarchar(500),
@usr_codigo smallint,
@tra_depban tinyint,
@doc_pdf	image	
as

declare @tra_id as int
update RSBtbparametro set @tra_id=doc_codigo+1, doc_codigo=doc_codigo+1 where anio=year(getdate())

insert cdtbtramite(tra_id,tra_codigo,tra_fecha,tra_tdoc,dep_codigo,tra_benf,tra_asunto,usr_codigo,tra_activado,tra_fechafx,tra_depban)
			values(@tra_id,@tra_codigo,@tra_fecha,@tra_tdoc,@dep_codigo,@tra_benf,@tra_asunto,@usr_codigo,1,getdate(),@tra_depban)
insert cdtbdocumento(tra_id,doc_pdf,doc_rec,doc_activado,doc_tipe)
		values(@tra_id,@doc_pdf,0,1,1)


go

