

CREATE  procedure [dbo].[spi_resol]
@res_codigo nvarchar(15),
@res_descripcion nvarchar(1000),
@raz_codigo smallint,
@res_coddoc nvarchar(30),
@pro_codigo smallint,
@res_adjudica nchar(100),
@res_fecha smalldatetime,
@cod_usr smallint,
@host nchar(20),
@adress nchar(20)
as 
declare @bit as tinyint
set @bit=0
if not exists(select res_codigo from RBStbResolc where res_codigo=@res_codigo and res_activado=1)
begin
	insert RBStbResolc(res_codigo,res_descripcion,raz_codigo,res_adjudica,res_fecha,res_activado,res_coddoc,pro_codigo)
			values(@res_codigo,@res_descripcion,@raz_codigo,@res_adjudica,@res_fecha,1,@res_coddoc,@pro_codigo)
	exec spi_auditoriaP @cod_usr,'spi_resol','Ingreso Resolución',@host ,@adress
end
else
begin
set @bit =1
end 
select @bit as bit

go

