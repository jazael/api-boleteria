

CREATE procedure [dbo].[spi_usuario]
@dep_codigo tinyint,
@usr_user varchar(50),
@usr_password varchar(50),
@usr_apellido varchar(50),
@usr_nombre varchar(50),
@tusu_codigo tinyint,
@usr_correo varchar(50),
@usr_activado bit,
@cod_usr smallint,
@host nchar(20),
@adress nchar(20)
as 
declare @usr_codigo as smallint
declare @bit as tinyint
set @bit=0

set @usr_codigo=Isnull((select max(usr_codigo) from dbo.wftbusuario),0)+1
if not exists(select usr_codigo from wftbusuario where usr_user=@usr_user)
begin
	insert wftbusuario(dep_codigo,usr_codigo,usr_user,usr_password,usr_apellido,usr_nombre,tusu_codigo,usr_correo,usr_fecha,usr_activado)
			values(@dep_codigo,@usr_codigo,@usr_user,@usr_password,@usr_apellido,@usr_nombre,@tusu_codigo,@usr_correo,getdate(),@usr_activado)
insert RBSTBdep_usr (dep_codigo,usr_codigo,deu_activado)values(@dep_codigo,@usr_codigo,1)
exec spi_auditoriaP @cod_usr,'spi_usuario','Ingreso de Usuarios',@host ,@adress


end
else
begin
set @bit =1
end 
select @bit as bit, @usr_codigo as codigo

