
CREATE PROCEDURE spu_apwrinforme
@rri_Id numeric(18,0),
@rri_noficnoti varchar(50),
@rri_femisioninf datetime,
@rri_frecepcioninf datetime,
@rri_ninforme varchar(50),
@rri_faprobacion datetime,
@rri_finicio datetime,
@rri_ffin datetime,
@rri_alcance varchar(250),
@emi_id tinyint,
@rri_nominforme varchar(250),
@rri_informe image,
@rri_activado bit

AS

IF(@rri_nominforme<>'')
BEGIN
Update dbo.RItbinforme Set
rri_noficnoti=@rri_noficnoti,
rri_femisioninf=@rri_femisioninf,
rri_frecepcioninf=@rri_frecepcioninf,
rri_ninforme=@rri_ninforme,
rri_faprobacion=@rri_faprobacion,
rri_finicio=@rri_finicio,
rri_ffin=@rri_ffin,
rri_alcance=@rri_alcance,
emi_id=@emi_id,
rri_nominforme=@rri_nominforme,
rri_informe=@rri_informe,
rri_activado=@rri_activado
where rri_Id=@rri_Id
END

IF(@rri_nominforme='')
BEGIN
Update dbo.RItbinforme Set
rri_noficnoti=@rri_noficnoti,
rri_femisioninf=@rri_femisioninf,
rri_frecepcioninf=@rri_frecepcioninf,
rri_ninforme=@rri_ninforme,
rri_faprobacion=@rri_faprobacion,
rri_finicio=@rri_finicio,
rri_ffin=@rri_ffin,
rri_alcance=@rri_alcance,
emi_id=@emi_id,
rri_activado=@rri_activado
where rri_Id=@rri_Id
END
go

