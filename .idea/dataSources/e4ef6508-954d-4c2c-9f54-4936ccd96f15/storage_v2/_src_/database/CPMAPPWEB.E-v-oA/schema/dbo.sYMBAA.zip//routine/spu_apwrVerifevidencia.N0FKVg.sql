
CREATE procedure spu_apwrVerifevidencia
@red_id numeric(18,0),
@validada char(1),
@red_motivo varchar(max)
As
Update REAtbevidenciadet Set red_estado=@validada, red_motivo=@red_motivo where red_id=@red_id
go

