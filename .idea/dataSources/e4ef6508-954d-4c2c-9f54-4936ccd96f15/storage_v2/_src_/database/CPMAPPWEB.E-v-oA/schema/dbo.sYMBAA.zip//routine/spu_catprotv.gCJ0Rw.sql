create procedure spu_catprotv
@pro_id int,
@pro_detalle nvarchar(3000),
@pro_fecha smalldatetime,
@pro_responsable nvarchar(100),
@pro_observa nvarchar(300),
@pro_activado bit,
@cod_usr smallint,
@host nchar(20),
@adress nchar(20)
as
update PRtbcaset set
pro_detalle=@pro_detalle,
pro_fecha=@pro_fecha,
pro_responsable=@pro_responsable,
pro_observa=@pro_observa,
pro_activado=@pro_activado
where pro_id=@pro_id

exec spi_auditoriaP @cod_usr,'spu_catprotv','Actualización de Casettes',@host ,@adress

go

