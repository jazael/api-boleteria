
CREATE Procedure spc_ver_cerrEvidencia
@red_Id numeric(18,0)
AS
Select count(red_id) red_id from REAtbevidenciadet Where red_id=@red_Id  and red_estado=0 and red_motivo=''
go

