CREATE Procedure spc_apwInfRecTodos
@tipo char(1),
@buscarpor varchar(80)
AS

IF(@buscarpor='')
Begin
SELECT DISTINCT rec.rri_id, rin.rri_ninforme FROM RRItbrecomendacion AS rec INNER JOIN RItbinforme AS rin ON rec.rri_id = rin.rri_Id
WHERE (rin.rri_activado = 1) ORDER BY rec.rri_id DESC
End

IF((@buscarpor<>'') and (@tipo=1))
Begin
SELECT DISTINCT rec.rri_id, rin.rri_ninforme FROM RRItbrecomendacion AS rec INNER JOIN RItbinforme AS rin ON rec.rri_id = rin.rri_Id
WHERE (rin.rri_activado = 1) and rin.rri_ninforme Like '%'+@buscarpor+'%' ORDER BY rec.rri_id DESC
End

IF((@buscarpor<>'') and (@tipo=2))
Begin
SELECT DISTINCT rec.rri_id, rin.rri_ninforme FROM RRItbrecomendacion AS rec INNER JOIN RItbinforme AS rin ON rec.rri_id = rin.rri_Id
WHERE (rin.rri_activado = 1) and rri_alcance Like '%'+@buscarpor+'%' ORDER BY rec.rri_id DESC
End
go

