CREATE PROCEDURE [dbo].[spu_pacdep]
@pan_id	int,
@invert tinyint,
@secuencia int,
@tic_codigo	tinyint,
@pan_deprod nvarchar(200),
@pan_cantidad	float,
@med_codigo	tinyint,
@pan_costo float,
@pan_tprodu varchar(20),
@pan_catalogo varchar(2),
@pan_regimen varchar(10),
@prc_codigo tinyint,
@pan_fbid varchar(2),
@pan_fbidpro varchar(50),
@pan_fbidcod varchar(50),
@cod_usr smallint
AS
declare @codigo_cl_inter as nvarchar(20)
declare @dep_codigo as smallint
declare @pan_anio as smallint
set @codigo_cl_inter=(select codigo_cl_inter  from rbstbpac where secuencia=@secuencia)
if @invert=1
begin
update RBStbpacanu set
codigo_cl_inter=@codigo_cl_inter,
secuencia=@secuencia,
tic_codigo=@tic_codigo,
pan_cantidad=@pan_cantidad,
pan_deprod=@pan_deprod,
med_codigo=@med_codigo,
pan_tprodu=@pan_tprodu,
pan_catalogo=@pan_catalogo,
pan_regimen=@pan_regimen,
prc_codigo=@prc_codigo,
pan_fbid=@pan_fbid,
pan_fbidpro=@pan_fbidpro,
pan_fbidcod=@pan_fbidcod,
pan_valid=1
where pan_id=@pan_id
end
else
begin
update RBStbpacanu set
codigo_cl_inter=@codigo_cl_inter,
secuencia=@secuencia,
tic_codigo=@tic_codigo,
pan_cantidad=@pan_cantidad,
pan_deprod=@pan_deprod,
med_codigo=@med_codigo,
pan_costo=@pan_costo,
pan_tprodu=@pan_tprodu,
pan_catalogo=@pan_catalogo,
pan_regimen=@pan_regimen,
prc_codigo=@prc_codigo,
pan_fbid=@pan_fbid,
pan_fbidpro=@pan_fbidpro,
pan_fbidcod=@pan_fbidcod,
pan_valid=1
where pan_id=@pan_id
end


exec spi_auditoriaP @cod_usr,'spu_pacdep','Registro Pac','' ,''
set @dep_codigo= (select dep_codigo from dbo.RBStbpacanu where pan_id=@pan_id )
set @pan_anio= (select pan_anio from dbo.RBStbpacanu where pan_id=@pan_id )
SELECT     ISNULL
((SELECT     SUM(pan_cantidad * pan_costo) AS total
FROM         dbo.RBStbpacanu WHERE     (dep_codigo = @dep_codigo) AND (pan_anio = @pan_anio) AND (pan_valid = 1) AND (pan_activado = 1)), 0) AS total
go

