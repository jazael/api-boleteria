create procedure [dbo].[spc_regapelT]
@valor varchar(13)
as
declare @reg_id as numeric(18,0)
if exists(SELECT reg_id FROM dbo.CMOtbregistro AS CMOtbregistro_1 WHERE (reg_cedula = SUBSTRING(@valor,4,10)) AND (per_id = SUBSTRING(@valor,2,2)))
begin
		set @reg_id = (SELECT MAX(reg_id) AS reg_id FROM dbo.CMOtbregistro AS CMOtbregistro_1 WHERE (reg_cedula = SUBSTRING(@valor,4,10)) AND (per_id = SUBSTRING(@valor,2,2)))
		if not exists( select reg_id from CMOtbapela where reg_id=@reg_id and tpe_codigo= SUBSTRING(@valor,1,1) )
			begin	
			SELECT     dbo.CMOtbregistro.reg_id, dbo.CMOtbregistro.reg_nombres, dbo.CMOtbregistro.reg_apellidos, dbo.CMOtbregistro.reg_contacto, dbo.CMOtbperfiles.per_denominacion, 
                      '' AS ban FROM dbo.CMOtbregistro INNER JOIN dbo.CMOtbperfiles ON dbo.CMOtbregistro.per_id = dbo.CMOtbperfiles.per_id
						WHERE (dbo.CMOtbregistro.reg_id = @reg_id)
			end
			else
			begin
			SELECT     '' as reg_id, '' as reg_nombres,'' as reg_apellidos,'' as reg_contacto,'' as per_denominacion, 'Usted ya registro una Postulación' as ban
			end
end
else
begin
SELECT     '' as reg_id, '' as reg_nombres,'' as reg_apellidos,'' as reg_contacto,'' as per_denominacion, 'Usted no se encuentra registrado' as ban
end

go

