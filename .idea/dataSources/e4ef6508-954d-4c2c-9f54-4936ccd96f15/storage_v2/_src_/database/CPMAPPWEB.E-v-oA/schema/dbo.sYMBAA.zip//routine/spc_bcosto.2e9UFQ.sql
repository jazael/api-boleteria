CREATE procedure spc_bcosto
@pan_deprod nvarchar(200),
@pan_id numeric(18,0)
as
declare @codigo_cl_inter nvarchar(50)
set @codigo_cl_inter=(select codigo_cl_inter from dbo.RBStbpacanu where pan_id=@pan_id)
if exists(SELECT     MAX(pan_costo) AS Expr1
FROM         dbo.RBStbpacanu
WHERE     (pan_anio = 2011) AND (pan_activado = 1) AND (pan_deprod like '%'+ @pan_deprod+'%'))
begin
		SELECT     MAX(pan_costo) AS d1
		FROM         dbo.RBStbpacanu
		WHERE     (pan_anio = 2011) AND (pan_activado = 1) AND (pan_deprod = @pan_deprod)
end
else
begin
		SELECT     MIN(pan_costo) AS d1
		FROM         dbo.RBStbpacanu
		WHERE     (pan_anio = 2011) AND (pan_activado = 1) AND (codigo_cl_inter = @codigo_cl_inter)
end

go

