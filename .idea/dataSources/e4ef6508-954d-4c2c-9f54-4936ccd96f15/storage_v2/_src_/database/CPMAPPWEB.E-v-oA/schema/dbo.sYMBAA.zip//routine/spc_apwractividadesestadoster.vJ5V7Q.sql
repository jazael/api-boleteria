Create Procedure spc_apwractividadesestadoster
@tipo char(1)
AS
--Todas
IF(@tipo=3)
BEGIN
Select distinct rec3.rri_id,act3.rec_id,rir.rri_ninforme,rir.rri_alcance,rec3.rec_recomendacion,
(count(rar_Id)) TotalAct,
(select count(act1.rec_id)  
from RRItbrecomendacion rec1 inner join RARTBActividad act1 on rec1.rec_id=act1.rec_id where rar_terminada=0 and rec1.rec_id=rec3.rec_id) AS Abierta,
(select count(rar_Id)  
from RRItbrecomendacion rec2 inner join RARTBActividad act2 on rec2.rec_id=act2.rec_id where rar_terminada=1 and rec3.rec_id=act2.rec_id) AS Cerrada
from RRItbrecomendacion rec3 inner join RARTBActividad act3 on rec3.rec_id=act3.rec_id 
Inner Join RItbinforme rir on rec3.rri_id=rir.rri_Id 
group by rec3.rri_id,rec3.rec_id, act3.rec_id,rir.rri_ninforme,rir.rri_alcance,rec3.rec_recomendacion
END

--Abierta
IF(@tipo=1)
BEGIN
Select distinct rec3.rri_id,act3.rec_id,rir.rri_ninforme,rir.rri_alcance,rec3.rec_recomendacion,
(count(rar_Id)) TotalAct,
(select count(act1.rec_id)  
from RRItbrecomendacion rec1 inner join RARTBActividad act1 on rec1.rec_id=act1.rec_id where rar_terminada=0 and rec1.rec_id=rec3.rec_id) AS Abierta,
(select count(rar_Id)  
from RRItbrecomendacion rec2 inner join RARTBActividad act2 on rec2.rec_id=act2.rec_id where rar_terminada=1 and rec3.rec_id=act2.rec_id) AS Cerrada
from RRItbrecomendacion rec3 inner join RARTBActividad act3 on rec3.rec_id=act3.rec_id 
Inner Join RItbinforme rir on rec3.rri_id=rir.rri_Id 
Where ((select count(act1.rec_id)  
from RRItbrecomendacion rec1 inner join RARTBActividad act1 on rec1.rec_id=act1.rec_id where rar_terminada=0 and rec1.rec_id=rec3.rec_id))>0
group by rec3.rri_id,rec3.rec_id, act3.rec_id,rir.rri_ninforme,rir.rri_alcance,rec3.rec_recomendacion
END

--Cerrada
IF(@tipo=2)
BEGIN
Select distinct rec3.rri_id,act3.rec_id,rir.rri_ninforme,rir.rri_alcance,rec3.rec_recomendacion,
(count(rar_Id)) TotalAct,
(select count(act1.rec_id)  
from RRItbrecomendacion rec1 inner join RARTBActividad act1 on rec1.rec_id=act1.rec_id where rar_terminada=0 and rec1.rec_id=rec3.rec_id) AS Abierta,
(select count(rar_Id)  
from RRItbrecomendacion rec2 inner join RARTBActividad act2 on rec2.rec_id=act2.rec_id where rar_terminada=1 and rec3.rec_id=act2.rec_id) AS Cerrada
from RRItbrecomendacion rec3 inner join RARTBActividad act3 on rec3.rec_id=act3.rec_id 
Inner Join RItbinforme rir on rec3.rri_id=rir.rri_Id
Where ((select count(act1.rec_id)  
from RRItbrecomendacion rec1 inner join RARTBActividad act1 on rec1.rec_id=act1.rec_id where rar_terminada=0 and rec1.rec_id=rec3.rec_id))=0
group by rec3.rri_id,rec3.rec_id, act3.rec_id,rir.rri_ninforme,rec3.rec_recomendacion,rir.rri_alcance
END
go

