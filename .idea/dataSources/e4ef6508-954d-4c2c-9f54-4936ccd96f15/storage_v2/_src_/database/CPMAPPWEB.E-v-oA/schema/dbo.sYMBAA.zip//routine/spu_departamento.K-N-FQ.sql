CREATE procedure [dbo].[spu_departamento]
@usr_codigo smallint,
@dep_codigo tinyint,
@dep_nombre varchar(50),
@dep_abre nchar(10),
@dep_depende tinyint,
@dep_rip nvarchar(20),
@dep_activado bit,
@host nchar(20),
@adress nchar(20)
as
declare @men as nvarchar(50)
set @men ='Proceso Completado'
if exists(SELECT     dbo.wftbuserdepart.usr_codigo
FROM         dbo.wftbdepartamento INNER JOIN
                      dbo.wftbuserdepart ON dbo.wftbdepartamento.dep_codigo = dbo.wftbuserdepart.dep_codigo
WHERE     (dbo.wftbdepartamento.dep_codigo = @dep_codigo))
begin
set @dep_activado=1
set @men ='No se puede realizar acción departamento con asignación'
end
if exists(SELECT     dbo.wftbusuario.usr_codigo
FROM         dbo.wftbdepartamento INNER JOIN
                      dbo.wftbusuario ON dbo.wftbdepartamento.dep_codigo = dbo.wftbusuario.dep_codigo
WHERE     (dbo.wftbdepartamento.dep_codigo = @dep_codigo))
begin
set @dep_activado=1
set @men ='No se puede realizar acción departamento con asignación'
end
update wftbdepartamento set
dep_nombre=@dep_nombre,
dep_abre=@dep_abre,
dep_depende=@dep_depende,
dep_rip =@dep_rip,
dep_activado=@dep_activado
where dep_codigo=@dep_codigo
exec spi_auditoriaP @usr_codigo,'spu_departamento','Modificación de Facultades',@host ,@adress

select @men as men
go

