CREATE procedure [dbo].[spi_addepart]
@dep_codigo smallint,
@usr_codigo tinyint,
@cod_usr smallint,
@host nchar(20),
@adress nchar(20)
as
insert wftbuserdepart(dep_codigo,usr_codigo,deu_activado)
values(@dep_codigo,@usr_codigo,1)
if not exists(select usr_codigo, dep_codigo from RBSTBdep_usr where usr_codigo=@usr_codigo and @dep_codigo=dep_codigo)
begin
insert RBSTBdep_usr(dep_codigo,usr_codigo,deu_activado)
values(@dep_codigo,@usr_codigo,1)
end
exec spi_auditoriaP @cod_usr,'spi_addepart','Permisos por Departamentos',@host ,@adress
go

