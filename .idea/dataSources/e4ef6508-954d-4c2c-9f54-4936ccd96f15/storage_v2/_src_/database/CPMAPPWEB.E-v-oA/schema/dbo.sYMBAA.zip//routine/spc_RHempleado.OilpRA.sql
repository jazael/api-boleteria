create procedure spc_RHempleado
@cedula nvarchar(10)
as
declare @fecha as smalldatetime
set @fecha= (select max(aur_fecha) from  CPMRRHH.dbo.rhtbasistenciaur)
SELECT        CPMRRHH.dbo.rhtbempleado.emp_nombre, CPMRRHH.dbo.rhtbempleado.emp_apellido, CPMRRHH.dbo.rhtbdepartamento.dep_descripcion, @fecha as fecha
FROM            CPMRRHH.dbo.rhtbempleado INNER JOIN
                         CPMRRHH.dbo.rhtbdepartamento ON CPMRRHH.dbo.rhtbempleado.dep_codigo = CPMRRHH.dbo.rhtbdepartamento.dep_codigo
WHERE        (CPMRRHH.dbo.rhtbempleado.emp_cedula = @cedula)
go

