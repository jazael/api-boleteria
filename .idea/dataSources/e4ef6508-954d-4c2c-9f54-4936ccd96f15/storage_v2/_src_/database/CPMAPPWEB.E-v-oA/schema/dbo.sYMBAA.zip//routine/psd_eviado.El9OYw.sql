

create procedure psd_eviado
@tra_id int
as
update cdtbtramite set
tra_codigoenv='',
tra_fechaenv= NULL,
tra_docenv='',
tra_enviado='',
tra_observa='',
tra_fechafxe=getdate()
where tra_id=@tra_id

update cdtbdocumento set
doc_activado=0
where tra_id=@tra_id and doc_rec=1


go

