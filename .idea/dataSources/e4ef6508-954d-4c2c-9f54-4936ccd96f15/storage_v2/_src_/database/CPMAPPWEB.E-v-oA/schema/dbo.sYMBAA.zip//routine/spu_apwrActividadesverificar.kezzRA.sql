CREATE PROCEDURE spu_apwrActividadesverificar
@rri_id numeric(18,0),
@rec_id numeric(18,0),
@emp_codigo smallint
AS
SELECT rar_Id,rri_id,rec_id,usr_codigo,rar_fechaini,rar_fechafin,rar_actividad,rar_estado 
FROM RARTBActividad 
where rri_id=@rri_id and rec_id=@rec_id and usr_codigo=(select usr_codigo from wftbusuario usu where emp_codigo=@emp_codigo) order by rar_actividad
go

