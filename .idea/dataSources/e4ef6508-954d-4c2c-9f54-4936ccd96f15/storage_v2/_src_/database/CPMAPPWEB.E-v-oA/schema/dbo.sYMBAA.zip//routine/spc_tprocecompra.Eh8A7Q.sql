CREATE procedure [dbo].[spc_tprocecompra]
@tic_codigo as tinyint,
@reg_codigo as tinyint,
@opt as tinyint =1
as
if @opt=2
begin
SELECT  distinct   dbo.RBStbProCompras.prc_codigo, dbo.RBStbProCompras.prc_descripcion
FROM         dbo.RBStbProCompras INNER JOIN
                      dbo.RBStbProTipCom ON dbo.RBStbProCompras.prc_codigo = dbo.RBStbProTipCom.prc_codigo
--where dbo.RBStbProCompras.prc_activado = 1
WHERE     (dbo.RBStbProTipCom.tic_codigo = @tic_codigo) AND (dbo.RBStbProCompras.prc_activado = 1) AND (dbo.RBStbProCompras.tic_compra = @reg_codigo)
order by prc_descripcion
end
else
begin 
SELECT  distinct   dbo.RBStbProCompras.prc_codigo, dbo.RBStbProCompras.prc_descripcion
FROM         dbo.RBStbProCompras INNER JOIN
                      dbo.RBStbProTipCom ON dbo.RBStbProCompras.prc_codigo = dbo.RBStbProTipCom.prc_codigo
where dbo.RBStbProCompras.prc_activado = 1
--WHERE     (dbo.RBStbProTipCom.tic_codigo = @tic_codigo) AND (dbo.RBStbProCompras.prc_activado = 1) AND (dbo.RBStbProCompras.tic_compra = @reg_codigo)
order by prc_descripcion

end

go

