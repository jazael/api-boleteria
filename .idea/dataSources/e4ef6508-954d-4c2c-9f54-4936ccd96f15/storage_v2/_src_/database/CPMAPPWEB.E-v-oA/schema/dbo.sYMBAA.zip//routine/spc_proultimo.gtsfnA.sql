
create procedure spc_proultimo
as
SELECT     pro_cassete, pro_detalle, pro_fecha
FROM         dbo.PRtbcaset
WHERE     (pro_id =
                          (SELECT     MAX(pro_id) AS Expr1
                            FROM          dbo.PRtbcaset AS PRtbcaset_1
                            WHERE      (pro_activado = 1)))
go

