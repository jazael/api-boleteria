
CREATE procedure [dbo].[spc_opcasig]
@usr_codigo smallint,
@opt_menu tinyint,
@cod_usr smallint,
@host nchar(20),
@adress nchar(20)
as
SELECT     dbo.wftbopcion_usuario.usr_codigo, dbo.wftbopcion_usuario.opt_codigo
FROM         dbo.wftbopcion_usuario INNER JOIN
                      dbo.wftbopciones ON dbo.wftbopcion_usuario.opt_codigo = dbo.wftbopciones.opt_codigo
WHERE     (dbo.wftbopcion_usuario.opu_activado = 1) AND (dbo.wftbopcion_usuario.usr_codigo = @usr_codigo) AND (dbo.wftbopciones.mod_codigo= @opt_menu) AND 
                      (opt_activado = 1)
exec spi_auditoriaP @cod_usr,'spc_opcasig','Consulta de Permisos',@host ,@adress

go

