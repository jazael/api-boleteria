CREATE PROCEDURE spi_regserrestemp
@rri_id numeric(18,0),
@emp_codigo smallint,
@usr_codigo smallint

as
Declare @rrt_id smallint
Select @rrt_id =isnull(max(rrt_id),0)+1 from RRDtbserrestemp
insert into RRDtbserrestemp(rrt_id,rri_id,emp_codigo,usr_codigo) values(@rrt_id,@rri_id,@emp_codigo,@usr_codigo)
go

