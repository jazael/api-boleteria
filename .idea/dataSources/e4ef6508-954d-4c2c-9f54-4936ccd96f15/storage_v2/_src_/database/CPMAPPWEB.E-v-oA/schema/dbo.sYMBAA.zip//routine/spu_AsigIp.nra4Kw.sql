create procedure spu_AsigIp
@reg_id numeric(18, 0),
@dep_codigo smallint,
@reg_fecha smalldatetime,
@reg_host nchar(50),
@reg_ubica nchar(150),
@reg_obser nchar(200),
@reg_inter bit

as 
declare @mensaje as nvarchar(50)
update CIPRegistro set 
dep_codigo=@dep_codigo,
reg_fecha=@reg_fecha,
reg_host=@reg_host,
reg_ubica=@reg_ubica,
reg_obser=@reg_obser,
reg_inter=@reg_inter
where reg_id=@reg_id

set @mensaje='Actualización Realizada con Exito'
select @mensaje as mensaje


go

