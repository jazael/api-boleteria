

CREATE PROCEDURE [dbo].[spr_pacdep]
@dep_codigo tinyint,
@pan_anio smallint,
@pan_tipg char(2),
@cod_usr as smallint,
@host nchar(20),
@adress nchar(20)
AS
if @pan_tipg ='1'
begin 
set @pan_tipg='GC'
end
else
begin 
set @pan_tipg='GI'
end

if @dep_codigo <> 99
begin
			SELECT dbo.RBStbpacanu.pan_anio, dbo.RBStbpacanu.codigo_cl_inter, dbo.RBStbtipcompra.tic_descripcion, dbo.RBStbpacanu.pan_deprod, 
									  dbo.RBStbpacanu.pan_cantidad, dbo.RBStbmedida.med_descripcion, CASE WHEN dbo.RBStbpacanu.pan_c1 = 1 THEN 'S' ELSE '' END AS c1, 
									  CASE WHEN dbo.RBStbpacanu.pan_c2 = 1 THEN 'S' ELSE '' END AS c2, CASE WHEN dbo.RBStbpacanu.pan_c3 = 1 THEN 'S' ELSE '' END AS c3, 
									  dbo.wftbdepartamento.dep_nombre, dbo.RBStbpacanu.pan_costo, dbo.RBStbpartidas.par_partida, CASE WHEN dbo.RBStbpacanu.pan_valid = 1 THEN ' ü ' ELSE ' û ' END AS aprobado
				FROM         dbo.RBStbpacanu INNER JOIN
									  dbo.RBStbtipcompra ON dbo.RBStbpacanu.tic_codigo = dbo.RBStbtipcompra.tic_codigo INNER JOIN
									  dbo.RBStbmedida ON dbo.RBStbpacanu.med_codigo = dbo.RBStbmedida.med_codigo INNER JOIN
									  dbo.wftbdepartamento ON dbo.RBStbpacanu.dep_codigo = dbo.wftbdepartamento.dep_codigo INNER JOIN
									  dbo.RBStbpartidas ON dbo.RBStbpacanu.par_codigo = dbo.RBStbpartidas.par_codigo
				WHERE     (dbo.RBStbpacanu.pan_activado = 1) AND (dbo.RBStbpacanu.pan_anio = @pan_anio) and dbo.RBStbpacanu.dep_codigo=@dep_codigo
				ORDER BY dbo.RBStbpacanu.dep_codigo, dbo.RBStbpacanu.pan_deprod
				
end
else
begin

			SELECT    dbo.RBStbpacanu.pan_anio, dbo.RBStbpacanu.codigo_cl_inter, dbo.RBStbtipcompra.tic_descripcion, dbo.RBStbpacanu.pan_deprod, 
								  dbo.RBStbpacanu.pan_cantidad, dbo.RBStbmedida.med_descripcion, CASE WHEN dbo.RBStbpacanu.pan_c1 = 1 THEN 'S' ELSE '' END AS c1, 
								  CASE WHEN dbo.RBStbpacanu.pan_c2 = 1 THEN 'S' ELSE '' END AS c2, CASE WHEN dbo.RBStbpacanu.pan_c3 = 1 THEN 'S' ELSE '' END AS c3, 
								  dbo.wftbdepartamento.dep_nombre,dbo.RBStbpartidas.par_partida,dbo.RBStbpacanu.pan_costo
			FROM         dbo.RBStbpacanu INNER JOIN
									  dbo.RBStbtipcompra ON dbo.RBStbpacanu.tic_codigo = dbo.RBStbtipcompra.tic_codigo INNER JOIN
									  dbo.RBStbmedida ON dbo.RBStbpacanu.med_codigo = dbo.RBStbmedida.med_codigo INNER JOIN
									  dbo.wftbdepartamento ON dbo.RBStbpacanu.dep_codigo = dbo.wftbdepartamento.dep_codigo INNER JOIN
									  dbo.RBStbpartidas ON dbo.RBStbpacanu.par_codigo = dbo.RBStbpartidas.par_codigo
			WHERE     (dbo.RBStbpacanu.pan_activado = 1) and (dbo.RBStbpacanu.pan_anio = @pan_anio)and pan_valid=1  --and pan_tipg=@pan_tipg
			ORDER BY dbo.RBStbpacanu.pan_deprod
			
end
exec spi_auditoriaP @cod_usr,'spr_pacdep','Impresión de PAC',@host ,@adress


go

