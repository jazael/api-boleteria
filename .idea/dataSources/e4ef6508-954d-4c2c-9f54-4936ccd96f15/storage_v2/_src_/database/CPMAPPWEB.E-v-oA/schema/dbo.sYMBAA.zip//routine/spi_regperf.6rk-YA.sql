


CREATE  procedure [dbo].[spi_regperf]
@per_denominacion	nvarchar(100),
@per_vacantes	tinyint,
@per_ciudad	nvarchar(50),
@per_publicado	bit,
@per_desde	datetime,
@per_hasta	datetime,
@per_activado	bit,
@usr_codigo smallint,
@per_bases	image	
as

insert CMOtbperfiles(per_denominacion, per_vacantes, per_ciudad, per_publicado, per_desde, per_hasta, per_ejecutado, per_activado, per_bases)
			values(@per_denominacion, @per_vacantes, @per_ciudad, @per_publicado, @per_desde, @per_hasta, 0, @per_activado, @per_bases)
--insert cdtbdocumento(tra_id,doc_pdf,doc_rec,doc_activado,doc_tipe)
--		values(@tra_id,@doc_pdf,0,1,1)


go

