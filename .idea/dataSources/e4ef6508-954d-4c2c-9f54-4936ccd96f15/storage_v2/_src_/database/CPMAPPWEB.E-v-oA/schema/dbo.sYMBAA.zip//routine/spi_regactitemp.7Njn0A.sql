CREATE PROCEDURE spi_regactitemp 
@rri_id numeric(18,0),
@rec_id numeric(18,0),
@usr_codigo smallint,
@rat_fechaini smalldatetime,
@rat_fechafin smalldatetime,
@rat_actividad varchar(max)
AS
Declare @rat_Id numeric(18,0)
Select @rat_Id=isnull(max(rat_Id),0)+1 from dbo.RARTBActividadTemp
Insert Into dbo.RARTBActividadTemp (rat_Id,rri_id,rec_id,usr_codigo,rat_fechaini,rat_fechafin,rat_actividad,rat_activado) 
Values (@rat_Id,@rri_id,@rec_id,@usr_codigo,@rat_fechaini,@rat_fechafin,@rat_actividad,'1')
go

