
CREATE procedure [dbo].[spc_banddoce]
@tra_env bit,
@tipo nvarchar(20),
@dep_codigo smallint
as
declare @consulta as nvarchar(2000)
declare @digito as tinyint

set @consulta ='SELECT     TOP (30) CASE WHEN EXISTS
                          (SELECT     doc_codigo
                            FROM          cdtbdocumento
                            WHERE      doc_activado = 1 AND dbo.cdtbdocumento.tra_id = tra_exid) THEN '+'''ü'''+' ELSE '+'''û'''+' END AS anexo, dbo.cdtbtramitex.tra_exid, dbo.cdtbtramitex.tra_control, SUBSTRING(dbo.octbcanton.can_nombre, 1, 10) AS can_nombre, 
                      SUBSTRING(dbo.cdtbtramitex.tra_origen, 1, 15) AS tra_origen, dbo.cdtbtramitex.tra_fecha, SUBSTRING(dbo.cdtbtramitex.tra_asunto, 1, 15) AS tra_asunto, 
                      dbo.CDtbtdocumento.tra_tdetalle
FROM         dbo.cdtbtramitex INNER JOIN
                      dbo.octbcanton ON dbo.cdtbtramitex.can_codigo = dbo.octbcanton.can_codigo INNER JOIN
                      dbo.CDtbtdocumento ON dbo.cdtbtramitex.tra_tdoc = dbo.CDtbtdocumento.tra_tdoc
WHERE     (dbo.cdtbtramitex.tra_activado = 1) and CDtbtramitex.tra_depban=' + convert(varchar(3),@dep_codigo)
if @tra_env =1
	begin
		set @consulta = 'SELECT     TOP (30) CASE WHEN EXISTS
                          (SELECT     doc_codigo
                            FROM          cdtbdocumento
                            WHERE      doc_activado = 1 AND dbo.cdtbdocumento.tra_id = tra_exid) THEN '+'''ü'''+' ELSE '+'''û'''+' END AS anexo, dbo.cdtbtramitex.tra_exid, dbo.cdtbtramitex.tra_control, SUBSTRING(dbo.octbcanton.can_nombre, 1, 10) AS can_nombre, 
                      SUBSTRING(dbo.cdtbtramitex.tra_origen, 1, 15) AS tra_origen, dbo.cdtbtramitex.tra_fenvio as tra_fecha, SUBSTRING(dbo.cdtbtramitex.tra_observacion, 1, 15) AS tra_asunto, 
                      dbo.CDtbtdocumento.tra_tdetalle
FROM         dbo.cdtbtramitex INNER JOIN
                      dbo.octbcanton ON dbo.cdtbtramitex.can_codigo = dbo.octbcanton.can_codigo INNER JOIN
                      dbo.CDtbtdocumento ON dbo.cdtbtramitex.tra_tdoc = dbo.CDtbtdocumento.tra_tdoc
WHERE     (dbo.cdtbtramitex.tra_activado = 1) and (dbo.cdtbtramitex.tra_fenvio IS NOT NULL) and (CDtbtramitex.tra_depban='+ convert(varchar(3),@dep_codigo) + ') '
	end
	else
		begin
			set @consulta =@consulta+' and (dbo.cdtbtramitex.tra_fenvio IS NULL)'
		end
if len(@tipo)>2
begin
	set @digito= cast(substring(@tipo,1,1) as tinyint)
	if @digito=1 
	begin
		set @consulta= @consulta + 'AND (tra_control LIKE ''' +'%'+  substring(@tipo,2,len(@tipo)) + '%'+''')'	
	end
	else
	begin
		if @digito=3
		begin
			set @consulta= @consulta + 'AND (tra_tdetalle LIKE '''+'%' +  substring(@tipo,2,len(@tipo)) +'%'+ ''' )'	
		end
		else
		begin
			if @digito=4
			begin
				set @consulta= @consulta + 'AND (tra_origen LIKE ''' +'%'+  substring(@tipo,2,len(@tipo)) +'%'+ ''' )'	
			end
			else
			begin
				set @consulta= @consulta + 'AND (tra_asunto LIKE ''' +'%'+  substring(@tipo,2,len(@tipo)) +'%'+ ''' )'	
			end
		end	
	end
end

set @consulta =@consulta + ' order by tra_fecha desc'

exec(@consulta)
go

