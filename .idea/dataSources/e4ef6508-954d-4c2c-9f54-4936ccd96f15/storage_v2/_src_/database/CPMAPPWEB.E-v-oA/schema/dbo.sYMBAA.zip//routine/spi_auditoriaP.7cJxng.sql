create procedure [dbo].[spi_auditoriaP]
@usr_codigo smallint,
@aud_proceso nchar(50),
@aud_opcion nchar(50),
@aud_adress nchar(20),
@aud_host nchar(20)

as
insert wftbauditoriaP(aud_proceso,aud_opcion,aud_usuario,aud_adress,aud_host,aud_fecha)
values(@aud_proceso,@aud_opcion,@usr_codigo,@aud_adress,@aud_host,getdate())
go

