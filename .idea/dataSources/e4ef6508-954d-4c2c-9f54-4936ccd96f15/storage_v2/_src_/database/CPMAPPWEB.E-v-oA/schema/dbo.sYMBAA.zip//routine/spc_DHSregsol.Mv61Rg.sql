
create  procedure spc_DHSregsol
@sol_codpro nvarchar(20)
as


SELECT        dbo.DHSRegistro.sol_codbpm AS CodigoAFlow, dbo.DHSRegistro.sol_apellido + ' ' + dbo.DHSRegistro.sol_nombre AS Solicitante, 'Solicitud ayuda Social' AS Tipo, dbo.DHSRegistro.sol_fecha AS FechaDocumento, 
                         dbo.DHSRegistro.sol_fecha AS Fecha, dbo.octbcanton.can_nombre AS Canton, dbo.octbparroquia.par_nombre AS Parroquia, 'Desarrollo Humano' AS Departamento, 'Registrado' AS Estado, 'XXXXXXXXXXX' AS Ingresado, 
                         dbo.DHSRegistro.sol_detalleR AS Resumen
FROM            dbo.DHSRegistro INNER JOIN
                         dbo.octbcanton ON dbo.DHSRegistro.can_codigo = dbo.octbcanton.can_codigo INNER JOIN
                         dbo.octbparroquia ON dbo.DHSRegistro.par_codigo = dbo.octbparroquia.par_codigo AND dbo.octbcanton.can_codigo = dbo.octbparroquia.can_codigo AND dbo.octbcanton.can_codigo = dbo.octbparroquia.can_codigo
WHERE        (dbo.DHSRegistro.sol_codpro = @sol_codpro)
go

