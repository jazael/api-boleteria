CREATE PROCEDURE [dbo].[spc_depart_dependencias]
@usr_codigo int,
@opcion tinyint =1
AS
if @opcion=2
begin 
SELECT DISTINCT dbo.wftbdepartamento.dep_nombre, dbo.wftbdepartamento.dep_codigo
FROM         dbo.wftbdepartamento INNER JOIN
                      dbo.RBStbpacanu ON dbo.wftbdepartamento.dep_codigo = dbo.RBStbpacanu.dep_codigo
WHERE     (dbo.RBStbpacanu.pan_activado = 1) AND (dbo.wftbdepartamento.pro_codigo <> 0)
ORDER BY dbo.wftbdepartamento.dep_nombre
end
else
begin
SELECT     wftbdepartamento.dep_codigo, wftbdepartamento.dep_nombre
FROM         wftbusuario INNER JOIN
                      RBSTBdep_usr ON wftbusuario.usr_codigo = RBSTBdep_usr.usr_codigo INNER JOIN
                      wftbdepartamento ON RBSTBdep_usr.dep_codigo = wftbdepartamento.dep_codigo
WHERE     (RBSTBdep_usr.usr_codigo = @usr_codigo)
ORDER BY wftbdepartamento.dep_nombre

end
go

