
CREATE procedure [dbo].[spc_banddoc]
@tra_env bit,
@tipo nvarchar(20),
@dep_codigo smallint 
as
declare @consulta as nvarchar(2000)
declare @digito as tinyint

set @consulta ='SELECT TOP (30) dbo.CDtbtramite.tra_id, dbo.CDtbtdocumento.tra_tdetalle, dbo.CDtbtramite.tra_codigo, dbo.CDtbtramite.tra_fecha, substring(dbo.wftbdepartamento.dep_nombre,1,15) as dep_nombre, 
                      substring(dbo.CDtbtramite.tra_benf,1,15) as tra_benf, substring(dbo.CDtbtramite.tra_asunto,1,15) as tra_asunto, CASE WHEN EXISTS
                          (SELECT     doc_codigo
                            FROM          cdtbdocumento
                            WHERE      doc_activado = 1 AND dbo.cdtbdocumento.tra_id = tra_id) THEN ' + '''ü'''+ ' ELSE ' + '''û''' + ' END AS anexo
FROM         dbo.CDtbtramite INNER JOIN
                      dbo.CDtbtdocumento ON dbo.CDtbtramite.tra_tdoc = dbo.CDtbtdocumento.tra_tdoc INNER JOIN
                      dbo.wftbdepartamento ON dbo.CDtbtramite.dep_codigo = dbo.wftbdepartamento.dep_codigo
WHERE     (dbo.CDtbtramite.tra_activado = 1) and CDtbtramite.tra_depban='+ convert(varchar(3),@dep_codigo)
if @tra_env =1
	begin
		set @consulta = 'SELECT  TOP (30)  dbo.CDtbtramite.tra_id, dbo.CDtbtdocumento.tra_tdetalle, dbo.CDtbtramite.tra_codigoenv as tra_codigo, dbo.CDtbtramite.tra_fechaenv as tra_fecha, substring(dbo.wftbdepartamento.dep_nombre,1,15) as dep_nombre, 
                      substring(dbo.CDtbtramite.tra_enviado,1,15) as tra_benf, substring(dbo.CDtbtramite.tra_observa,1,15) as tra_asunto, CASE WHEN EXISTS
                          (SELECT     doc_codigo
                            FROM          cdtbdocumento
                            WHERE      doc_activado = 1 AND dbo.cdtbdocumento.tra_id = tra_id) THEN ' + '''ü'''+ ' ELSE ' + '''û''' + ' END AS anexo
FROM         dbo.CDtbtramite INNER JOIN
                      dbo.CDtbtdocumento ON dbo.CDtbtramite.tra_docenv = dbo.CDtbtdocumento.tra_tdoc INNER JOIN
                      dbo.wftbdepartamento ON dbo.CDtbtramite.dep_codigo = dbo.wftbdepartamento.dep_codigo
WHERE     (dbo.CDtbtramite.tra_activado = 1) and (dbo.CDtbtramite.tra_fechaenv IS NOT NULL) and (CDtbtramite.tra_depban='+ convert(varchar(3),@dep_codigo) + ') '
	end
	else
		begin
			set @consulta =@consulta+' and (dbo.CDtbtramite.tra_fechaenv IS NULL)'
		end
if len(@tipo)>2
begin
	set @digito= cast(substring(@tipo,1,1) as tinyint)
	if @digito=1 
	begin
					set @consulta= @consulta + 'AND (tra_codigo LIKE ''' +'%'+  substring(@tipo,2,len(@tipo)) + '%'+''')'	
	end
	else
	begin
		if @digito=3
		begin
			set @consulta= @consulta + 'AND (tra_tdetalle LIKE '''+'%' +  substring(@tipo,2,len(@tipo)) +'%'+ ''' )'	
		end
		else
			begin
				if @digito=4
				begin
					set @consulta= @consulta + 'AND (tra_benf LIKE '''+'%' +  substring(@tipo,2,len(@tipo)) +'%'+ ''' )'	
				end
				else
				begin
				if @digito=5
					begin
					set @consulta= @consulta + 'AND (tra_codigoenv LIKE ''' +'%'+  substring(@tipo,2,len(@tipo)) + '%'+''')'
					end
					else
					begin
						if @digito=6
						begin
						set @consulta= @consulta + 'AND (dep_nombre LIKE '''+'%' +  substring(@tipo,2,len(@tipo)) +'%'+ ''' )'	
						end
						else
						begin
						set @consulta= @consulta + 'AND (tra_asunto LIKE '''+'%' +  substring(@tipo,2,len(@tipo)) +'%'+ ''' )'	
						end
					
				end
				end
			end
	end
end

set @consulta =@consulta + ' order by tra_fecha desc'
--if @dep_codigo=2 
--begin
exec(@consulta)
--end
go

