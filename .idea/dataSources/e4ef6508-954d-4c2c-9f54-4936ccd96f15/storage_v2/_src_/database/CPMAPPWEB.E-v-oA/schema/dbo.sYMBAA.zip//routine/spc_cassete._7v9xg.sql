CREATE procedure spc_cassete
@casete nvarchar(10),
@detalle  nvarchar(100),
@desde smalldatetime,
@hasta smalldatetime,
@cod_usr smallint,
@host nchar(20),
@adress nchar(20)
as
declare @consul as nvarchar(300)
set @consul='SELECT  pro_id, pro_cassete, substring(pro_detalle,1,100) as pro_detalle, pro_fecha FROM dbo.PRtbcaset where pro_activado= 1 '
if len(@casete)<> 0
begin
set @consul=@consul + 'and pro_cassete= ' + @casete
end
else
begin
	set @consul=@consul + ' and pro_fecha between '+ '''' + CONVERT(nvarchar(10), @desde, 103)+'''' + '  and  ' +''''+ CONVERT(nvarchar(10), @hasta, 103)+ '''' 
		if len(@detalle )<> 0
			begin
			set @consul=@consul + ' and pro_detalle LIKE  ' + ''''+ +'%'+rtrim(@detalle)+'%'+''''
			end	
end
exec spi_auditoriaP @cod_usr,'spc_cassete','Consultas de Cassetes',@host ,@adress
exec(@consul)
go

