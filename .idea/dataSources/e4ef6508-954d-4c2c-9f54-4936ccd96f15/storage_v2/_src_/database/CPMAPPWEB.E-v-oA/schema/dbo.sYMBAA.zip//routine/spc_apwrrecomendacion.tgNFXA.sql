CREATE Procedure spc_apwrrecomendacion
@rec_id numeric(18,0),
@usr_codigo smallint
as
SELECT rec.rec_id, rin.rri_Id, rin.rri_ninforme, rri_alcance, rri_faprobacion,rec_descripanalisis,rec_numrecomendacion,rec.rec_fechaini, rec.rec_fechafin, rec.rec_recomendacion,rec_activado
FROM RRItbrecomendacion AS rec INNER JOIN RItbinforme AS rin ON rec.rri_id = rin.rri_Id WHERE rec.rec_id=@rec_id

Declare @rri_id numeric(18,0)
Declare @car_codigo smallint
Declare @rdt_id smallint
--declare RRDtbserdirtemp cursor for SELECT rec.rec_id,rri_id,emp_codigo from RRDtbserdir dir inner join RRItbrecomendacion rec on dir.rec_id=rec.rec_id 
declare RRDtbserdirtemp cursor for SELECT rec.rec_id,rri_id,car_codigo from RRDtbserdir dir inner join RRItbrecomendacion rec on dir.rec_id=rec.rec_id 
where rec.rec_id=@rec_id
OPEN RRDtbserdirtemp
FETCH NEXT FROM RRDtbserdirtemp
INTO @rec_id,@rri_id,@car_codigo

WHILE @@FETCH_STATUS = 0
BEGIN
Select @rdt_id =isnull(max(rdt_id),0)+1 from RRDtbserdirtemp
--insert into RRDtbserdirtemp(rri_id,emp_codigo)
insert into RRDtbserdirtemp(rdt_id,rri_id,car_codigo,usr_codigo)
--Values(@rri_id,@emp_codigo)
Values(@rdt_id,@rri_id,@car_codigo,@usr_codigo)

FETCH NEXT FROM RRDtbserdirtemp
INTO @rec_id,@rri_id,@car_codigo
END   
CLOSE RRDtbserdirtemp
DEALLOCATE RRDtbserdirtemp
----------------------------
----------------------------
Declare @rrt_id smallint
Select @rrt_id =isnull(max(rrt_id),0)+1 from RRDtbserrestemp


Declare @emp_codigo smallint
declare RRDtbserrestemp cursor for SELECT rec.rec_id,rri_id,emp_codigo from RRDtbserres res inner join RRItbrecomendacion rec on res.rec_id=rec.rec_id 
where rec.rec_id=@rec_id
OPEN RRDtbserrestemp
FETCH NEXT FROM RRDtbserrestemp
INTO @rec_id,@rri_id,@emp_codigo

WHILE @@FETCH_STATUS = 0
BEGIN
Select @rrt_id =isnull(max(rrt_id),0)+1 from RRDtbserrestemp
insert into RRDtbserrestemp(rrt_id,rri_id,emp_codigo,usr_codigo)
Values(@rrt_id,@rri_id,@emp_codigo,@usr_codigo)

FETCH NEXT FROM RRDtbserrestemp
INTO @rec_id,@rri_id,@emp_codigo
END   
CLOSE RRDtbserrestemp
DEALLOCATE RRDtbserrestemp
go

