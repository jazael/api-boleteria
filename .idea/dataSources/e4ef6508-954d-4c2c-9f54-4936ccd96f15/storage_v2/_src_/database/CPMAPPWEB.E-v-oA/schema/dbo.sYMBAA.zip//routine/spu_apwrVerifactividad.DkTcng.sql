CREATE procedure spu_apwrVerifactividad
@rar_id numeric(18,0),
@validada char(1),
@rar_motivo varchar(max)
As
Update RARTBActividad Set rar_estado=@validada, rar_motivo=@rar_motivo where rar_id=@rar_id
go

