CREATE PROCEDURE spi_apwrinforme
@rri_noficnoti varchar(50),
@rri_femisioninf datetime,
@rri_frecepcioninf datetime,
@rri_ninforme varchar(50),
@rri_faprobacion datetime,
@rri_finicio datetime,
@rri_ffin datetime,
@rri_alcance varchar(250),
@emi_id tinyint,
@rri_nominforme varchar(250),
@rri_informe image

AS
declare @rri_Id numeric (18,0)
--declare @rid_codigo numeric(18,0)
select @rri_Id =isnull(max(rri_Id),0)+1 from dbo.RItbinforme
--select @rid_codigo =isnull(max(rid_codigo),0)+1 from RItbinformeDocumento

Insert Into dbo.RItbinforme (rri_Id,rri_noficnoti,rri_femisioninf,rri_frecepcioninf,rri_ninforme,rri_faprobacion,rri_finicio,rri_ffin,rri_alcance,emi_id,rri_activado,rri_nominforme,rri_informe)
Values(@rri_Id,@rri_noficnoti,@rri_femisioninf,@rri_frecepcioninf,@rri_ninforme,@rri_faprobacion,@rri_finicio,@rri_ffin,@rri_alcance,@emi_id,1,@rri_nominforme,@rri_informe)



--Insert Into RItbinformeDocumento (rid_codigo,rri_id,rid_informe,rid_detalle,rid_activado)
--Values(@rid_codigo,@rri_Id,@rri_informe,'',1)
go

