
CREATE Procedure spc_apwrevidenciasestadoter
@rev_id numeric(18,0)
AS
--Select red_id,red_descripcion,red_nomevidencia,red_estado,red_motivo,
--(Select count(red_estado)  from REAtbevidenciadet red where rev_id=1 and red_estado=0) as abiertas
--from REAtbevidencia rev Inner Join REAtbevidenciadet red on rev.rev_id=red.rev_id where rev.rev_id=1



Select red_id,red_descripcion,red_nomevidencia,red_estado,red_motivo,
(Select count(red_estado)  from REAtbevidenciadet red where rev_id=(Select rev_id from REAtbevidencia where rar_id=@rev_id) and red_estado=0) as abiertas
from REAtbevidencia rev Inner Join REAtbevidenciadet red on rev.rev_id=red.rev_id where rev.rev_id=(Select rev_id from REAtbevidencia where rar_id=@rev_id)
go

