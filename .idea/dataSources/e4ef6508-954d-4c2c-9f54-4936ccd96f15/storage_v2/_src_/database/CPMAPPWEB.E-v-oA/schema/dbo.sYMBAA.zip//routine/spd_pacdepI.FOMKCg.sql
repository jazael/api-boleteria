
create PROCEDURE [dbo].[spd_pacdepI]
	@pan_id as numeric(18,0),
	@usr_codigo as smallint
AS

update RBStbpacanu set 
pan_activado=0,
pan_fecha=getdate()
where pan_id=@pan_id
exec spi_auditoriaP @usr_codigo,'spd_pacdep','anulación de Pac','' ,''

go

