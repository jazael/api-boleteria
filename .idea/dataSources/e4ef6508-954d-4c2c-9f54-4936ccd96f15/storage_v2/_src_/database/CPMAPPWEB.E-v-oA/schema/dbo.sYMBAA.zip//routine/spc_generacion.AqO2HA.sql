
CREATE  PROCEDURE [dbo].[spc_generacion] 
@cad_codigo as int,
@cod_usr as smallint,
@host nchar(20),
@adress nchar(20)
AS
declare @adminis as nvarchar(100)
declare @num_ordenes as int
declare @cad_codigoR as bigint
declare @cad_fecha as datetime
declare @cad_observacion as nvarchar(1000)
declare @dep_nombre as nvarchar(50)
declare @nombres as nvarchar(100)
--declare @gru_descripcion as nvarchar(80)
declare @ite_descripcion as nvarchar(1000)
declare @ite_cod_referencial as nvarchar(25)
declare @det_cantidad as smallmoney
declare @det_detalle as nchar(200)
--declare @ite_creferencial as smallmoney
--declare @sub_descripcion as nvarchar(80)
declare @dirrec as nvarchar(100)
declare @det_pac as int
declare @fecha as smalldatetime
declare @i as tinyint
set @i=0
exec spi_auditoriaP @cod_usr,'spc_generacion','Impresión de Orden',@host ,@adress

DECLARE @tabla TABLE (cad_codigo int, cad_fecha datetime, cad_observacion nvarchar(1000), dep_nombre nvarchar(50), nombres nvarchar(100) , ite_descripcion nvarchar(1200), ite_cod_referencial nvarchar(50), det_cantidad smallmoney,  dirrec nvarchar(100),det_pac int)
set @fecha=(select cad_fecha from RBStbcadord where cad_codigo=@cad_codigo)
set @adminis = (select nomdir from RSBtbparametro WHERE ANIO=Year(@fecha) )
set @num_ordenes = (SELECT     COUNT(*) AS Expr1 fROM dbo.RBStbdetord WHERE (det_activado = 1) AND (cad_codigo = @cad_codigo))

declare detalle cursor for SELECT     dbo.RBStbcadord.cad_codigo, dbo.RBStbcadord.cad_fecha, dbo.RBStbcadord.cad_observacion, dbo.wftbdepartamento.dep_nombre, 
                      dbo.wftbusuario.usr_nombre + ' ' + dbo.wftbusuario.usr_apellido AS nombres, dbo.RBStbpac.nombre_cl_inter,dbo.RBStbdetord.ite_codigo, dbo.RBStbdetord.det_cantidad,dbo.RBStbdetord.det_detalle, @adminis,det_pac                     
FROM         dbo.RBStbcadord INNER JOIN
                      dbo.RBStbdetord ON dbo.RBStbcadord.cad_codigo = dbo.RBStbdetord.cad_codigo INNER JOIN
                      dbo.wftbdepartamento ON dbo.RBStbcadord.dep_codigo = dbo.wftbdepartamento.dep_codigo INNER JOIN
                      dbo.wftbusuario ON dbo.RBStbcadord.usr_codigo = dbo.wftbusuario.usr_codigo INNER JOIN
                      dbo.RBStbpac ON dbo.RBStbdetord.ite_secuencia = dbo.RBStbpac.secuencia
WHERE     (dbo.RBStbcadord.cad_activado = 1) AND (dbo.RBStbcadord.cad_codigo = @cad_codigo)

OPEN detalle
FETCH NEXT FROM detalle
INTO @cad_codigoR, @cad_fecha , @cad_observacion,@dep_nombre, @nombres, @ite_descripcion,  @ite_cod_referencial,@det_cantidad,@det_detalle,@dirrec,@det_pac
WHILE @@FETCH_STATUS = 0
BEGIN
set @i=@i+1
		if @det_pac <> 0
		begin
			set @ite_descripcion = (select pan_deprod from RBStbpacanu where pan_id=@det_pac )
		end
		insert  @tabla (cad_codigo , cad_fecha , cad_observacion , dep_nombre , nombres , ite_descripcion , ite_cod_referencial , det_cantidad ,  dirrec,det_pac)
		values (@cad_codigoR, @cad_fecha , @cad_observacion,@dep_nombre, @nombres, Substring(@ite_descripcion,1,50)+'.- '+@det_detalle,  @ite_cod_referencial,@det_cantidad, @dirrec,@det_pac)
		
--			if @num_ordenes=@i and @num_ordenes < 6
--			begin
--					while @num_ordenes < 6
--						begin
--								insert  @tabla (cad_codigo , cad_fecha , cad_observacion , dep_nombre , nombres ,ite_descripcion , ite_cod_referencial , det_cantidad, dirrec)
--								values (@cad_codigoR, @cad_fecha , @cad_observacion,@dep_nombre, @nombres, '***********',  '-','-', @dirrec)
--								set @num_ordenes=@num_ordenes+1	
--						end
--			end
FETCH NEXT FROM detalle
INTO @cad_codigoR, @cad_fecha , @cad_observacion,@dep_nombre, @nombres, @ite_descripcion,  @ite_cod_referencial,@det_cantidad,@det_detalle,@dirrec,@det_pac
END	

CLOSE detalle
DEALLOCATE detalle
select *  from @tabla


go

