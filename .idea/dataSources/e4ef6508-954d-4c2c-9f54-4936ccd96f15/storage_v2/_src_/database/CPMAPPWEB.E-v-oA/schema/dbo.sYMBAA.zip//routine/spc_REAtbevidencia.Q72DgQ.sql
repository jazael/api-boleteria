CREATE Procedure spc_REAtbevidencia
@rar_id NUMERIC (18,0)
AS
--Select red_id,rev.rev_id,red_descripcion,red_nomevidencia,red_evidencia,red_estado,red_motivo 
--from REAtbevidencia rev inner join REAtbevidenciadet red on rev.rev_id=red.rev_id where rar_id=@rar_id

Select red_id,rev.rev_id,red_descripcion,red_nomevidencia,red_evidencia,red_estado,CASE WHEN red_estado='' then 'NO' else 'SI' end red_motivo 
from REAtbevidencia rev inner join REAtbevidenciadet red on rev.rev_id=red.rev_id where rar_id=@rar_id
go

