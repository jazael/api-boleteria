CREATE PROCEDURE [dbo].[spc_pacdep]
@dep_codigo tinyint,
@pan_anio smallint
AS
SELECT     dbo.RBStbpacanu.pan_id,dbo.RBStbpacanu.codigo_cl_inter, SUBSTRING(dbo.RBStbpac.nombre_cl_inter, 1, 100) AS nombrecpc, dbo.RBStbtipcompra.tic_descripcion, 
                      dbo.RBStbpacanu.pan_deprod, dbo.RBStbpacanu.pan_cantidad,pan_costo, CASE WHEN dbo.RBStbpacanu.pan_c1 = 1 THEN 'S' ELSE '-' END AS c1, 
                      CASE WHEN dbo.RBStbpacanu.pan_c2 = 1 THEN 'S' ELSE '-' END AS c2, CASE WHEN dbo.RBStbpacanu.pan_c3 = 1 THEN 'S' ELSE '-' END AS c3
FROM         dbo.RBStbpacanu INNER JOIN
                      dbo.RBStbpac ON dbo.RBStbpacanu.secuencia = dbo.RBStbpac.secuencia INNER JOIN
                      dbo.RBStbtipcompra ON dbo.RBStbpacanu.tic_codigo = dbo.RBStbtipcompra.tic_codigo
WHERE     (dbo.RBStbpacanu.pan_anio = @pan_anio) AND (dbo.RBStbpacanu.dep_codigo = @dep_codigo) AND (dbo.RBStbpacanu.pan_activado = 1)
order by pan_id desc
go

