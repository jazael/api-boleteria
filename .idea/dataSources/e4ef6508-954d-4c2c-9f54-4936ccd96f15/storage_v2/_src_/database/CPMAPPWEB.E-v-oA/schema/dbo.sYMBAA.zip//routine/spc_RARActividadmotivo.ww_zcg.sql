CREATE PROCEDURE spc_RARActividadmotivo @rar_Id numeric(18,0) AS SELECT rar_Id,rar_motivo FROM RARTBActividad where rar_Id=@rar_Id
go

