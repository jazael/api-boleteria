create procedure spi_catprotv
@pro_cassete int,
@pro_detalle nvarchar(3000),
@pro_fecha smalldatetime,
@pro_responsable nvarchar(100),
@pro_observa nvarchar(300),
@cod_usr smallint,
@host nchar(20),
@adress nchar(20)
as
declare @pro_id as int
update RSBtbparametro set @pro_id=cod_grupo+1, cod_grupo=cod_grupo+1 where anio=2010
insert PRtbcaset (pro_id,pro_cassete,pro_detalle,pro_fecha,pro_responsable,pro_observa,pro_activado)
		   values(@pro_id,@pro_cassete,@pro_detalle,@pro_fecha,@pro_responsable,@pro_observa,1)

exec spi_auditoriaP @cod_usr,'spi_catprotv','Registro de Casettes',@host ,@adress

go

