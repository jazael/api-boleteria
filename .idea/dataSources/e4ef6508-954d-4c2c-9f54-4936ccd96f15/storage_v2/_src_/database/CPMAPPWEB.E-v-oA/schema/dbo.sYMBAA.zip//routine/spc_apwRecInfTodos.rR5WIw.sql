CREATE Procedure spc_apwRecInfTodos
@tipo char(1),
@buscarpor varchar(80)
--@rri_Id numeric(18,0),
--@rec_recomendacion  varchar(80)
AS
if(@buscarpor=' ')
Begin
Set @buscarpor=''
End

IF((@buscarpor<>'') and (@tipo=1))
Begin
SELECT rec.rec_id, rin.rri_Id, rin.rri_ninforme, rec.rec_fechaini, rec.rec_fechafin, rec.rec_recomendacion 
FROM RRItbrecomendacion AS rec INNER JOIN RItbinforme AS rin ON rec.rri_id = rin.rri_Id
WHERE (rec.rec_activado = 1) /*and rin.rri_Id=@rri_Id*/ and rin.rri_ninforme Like '%'+@buscarpor+'%' ORDER BY rec.rec_fechaini 
End

IF((@buscarpor='') and (@tipo=1))
Begin
SELECT top(20)rec.rec_id, rin.rri_Id, rin.rri_ninforme, rec.rec_fechaini, rec.rec_fechafin, rec.rec_recomendacion 
FROM RRItbrecomendacion AS rec INNER JOIN RItbinforme AS rin ON rec.rri_id = rin.rri_Id
WHERE (rec.rec_activado = 1) /*and rin.rri_Id=@rri_Id*/ and rin.rri_ninforme Like '%'+@buscarpor+'%' ORDER BY rec.rec_fechaini
End

IF((@buscarpor<>'') and (@tipo=2))
Begin
SELECT rec.rec_id, rin.rri_Id, rin.rri_ninforme, rec.rec_fechaini, rec.rec_fechafin, rec.rec_recomendacion 
FROM RRItbrecomendacion AS rec INNER JOIN RItbinforme AS rin ON rec.rri_id = rin.rri_Id
WHERE (rec.rec_activado = 1) /*and rin.rri_Id=@rri_Id*/ and rri_alcance Like '%'+@buscarpor+'%'  ORDER BY rec.rec_fechaini
End

IF((@buscarpor='') and (@tipo=2))
Begin
SELECT top(20) rec.rec_id, rin.rri_Id, rin.rri_ninforme, rec.rec_fechaini, rec.rec_fechafin, rec.rec_recomendacion 
FROM RRItbrecomendacion AS rec INNER JOIN RItbinforme AS rin ON rec.rri_id = rin.rri_Id
WHERE (rec.rec_activado = 1) /*and rin.rri_Id=@rri_Id*/ and rri_alcance Like '%'+@buscarpor+'%'  ORDER BY rec.rec_fechaini
End

IF((@buscarpor<>'') and (@tipo=3))
Begin
SELECT rec.rec_id, rin.rri_Id, rin.rri_ninforme, rec.rec_fechaini, rec.rec_fechafin, rec.rec_recomendacion 
FROM RRItbrecomendacion AS rec INNER JOIN RItbinforme AS rin ON rec.rri_id = rin.rri_Id
WHERE (rec.rec_activado = 1) /*and rin.rri_Id=@rri_Id*/ and (rec.rec_recomendacion Like '%'+@buscarpor+'%')  ORDER BY rec.rec_fechaini
End


IF((@buscarpor='') and (@tipo=3))
Begin
SELECT top(20)rec.rec_id, rin.rri_Id, rin.rri_ninforme, rec.rec_fechaini, rec.rec_fechafin, rec.rec_recomendacion 
FROM RRItbrecomendacion AS rec INNER JOIN RItbinforme AS rin ON rec.rri_id = rin.rri_Id
WHERE (rec.rec_activado = 1) /*and rin.rri_Id=@rri_Id*/ and (rec.rec_recomendacion Like '%'+@buscarpor+'%') ORDER BY rec.rec_fechaini
End


--SELECT top(20)rec.rec_id, rin.rri_Id, rin.rri_ninforme, rec.rec_fechaini, rec.rec_fechafin, rec.rec_recomendacion 
--FROM RRItbrecomendacion AS rec INNER JOIN RItbinforme AS rin ON rec.rri_id = rin.rri_Id
--WHERE (rec.rec_activado = 1) and rin.rri_Id=@rri_Id and (rec.rec_recomendacion Like '%'+@rec_recomendacion +'%') ORDER BY rec.rec_fechaini DESC
go

