CREATE PROCEDURE [dbo].[spi_pacdep]
@dep_codigo	tinyint,
@pan_anio	smallint,
@secuencia	int,
@tic_codigo	tinyint,
@tip_gasto tinyint,
@pan_deprod	nvarchar(200),
@pan_cantidad	float,
@pan_costo	float,
@med_codigo	tinyint,
@pan_c1	bit,
@pan_c2	bit,
@pan_c3	bit,
@pry_id numeric(18,0) =0,
@pro_id numeric(18,0) =0,
@m1 tinyint,
@m2 tinyint,
@m3 tinyint,
@cod_usr smallint

AS
declare @codigo_cl_inter as nvarchar(50)
declare @gasto as nchar(2)
declare @pan_valid as tinyint
set @pan_valid= 0
set @gasto='GC'
if @tip_gasto=2
begin
set @gasto='GI'
end

set @codigo_cl_inter=(select codigo_cl_inter from rbstbpac where secuencia=@secuencia)
insert RBStbpacanu(dep_codigo,pan_anio,par_codigo,codigo_cl_inter,secuencia,tic_codigo,pan_deprod,pan_cantidad,med_codigo,pan_c1,pan_c2,pan_c3,pan_activado,pan_valid,pan_tipg,pan_costo,pry_id,pro_id,pan_m1,pan_m2,pan_m3)
	Values(@dep_codigo,@pan_anio,0,@codigo_cl_inter,@secuencia,@tic_codigo,@pan_deprod,@pan_cantidad,@med_codigo,@pan_c1,@pan_c2,@pan_c3,1,@pan_valid,@gasto,@pan_costo,@pry_id,@pro_id,@m1,@m2,@m3)
exec spi_auditoriaP @cod_usr,'spi_pacdep','Registro Pac','' ,''
go

