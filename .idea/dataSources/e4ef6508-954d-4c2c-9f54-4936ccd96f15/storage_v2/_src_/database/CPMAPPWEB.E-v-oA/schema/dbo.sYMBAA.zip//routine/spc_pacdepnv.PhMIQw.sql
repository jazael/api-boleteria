CREATE PROCEDURE [dbo].[spc_pacdepnv]
@dep_codigo tinyint,
@pan_anio smallint,
@opcion tinyint
AS
if @opcion=1
begin
SELECT     dbo.RBStbpacanu.pan_id, dbo.RBStbtipcompra.tic_descripcion, dbo.RBStbpacanu.codigo_cl_inter, dbo.RBStbpacanu.pan_deprod, 
                      dbo.RBStbpacanu.pan_cantidad,dbo.RBStbpacanu.pan_costo,(pan_cantidad*pan_costo) as total
FROM         dbo.RBStbpacanu INNER JOIN
                      dbo.RBStbtipcompra ON dbo.RBStbpacanu.tic_codigo = dbo.RBStbtipcompra.tic_codigo
WHERE     (dbo.RBStbpacanu.pan_activado = 1) AND (dbo.RBStbpacanu.pan_valid = 1) AND (dbo.RBStbpacanu.dep_codigo = @dep_codigo) AND 
                      (dbo.RBStbpacanu.pan_anio = @pan_anio)
order by codigo_cl_inter
end

else
begin
		if @opcion=2
			begin
				SELECT     TOP (100) PERCENT dbo.RBStbpacanu.pan_id, dbo.RBStbtipcompra.tic_descripcion, dbo.RBStbpacanu.pan_deprod, 
										  dbo.RBStbpacanu.pan_cantidad * dbo.RBStbpacanu.pan_costo AS total
					FROM         dbo.RBStbpacanu INNER JOIN
										  dbo.RBStbtipcompra ON dbo.RBStbpacanu.tic_codigo = dbo.RBStbtipcompra.tic_codigo
					WHERE     (dbo.RBStbpacanu.pan_activado = 1) AND (dbo.RBStbpacanu.pan_valid = 1) AND (dbo.RBStbpacanu.dep_codigo = @dep_codigo) AND 
										  (dbo.RBStbpacanu.pan_anio = @pan_anio)AND (dbo.RBStbpacanu.par_codigo = 0)
					ORDER BY dbo.RBStbpacanu.codigo_cl_inter
			end
		else
	begin
			if @opcion=3
				begin
						SELECT     TOP (100) PERCENT dbo.RBStbpacanu.pan_id, dbo.RBStbpacanu.pan_deprod, dbo.RBStbpartidas.par_partida AS partida, 
												  dbo.RBStbpacanu.pan_cantidad * dbo.RBStbpacanu.pan_costo AS total
							FROM         dbo.RBStbpacanu INNER JOIN
												  dbo.RBStbpartidas ON dbo.RBStbpacanu.par_codigo = dbo.RBStbpartidas.par_codigo
							WHERE     (dbo.RBStbpacanu.pan_activado = 1) AND (dbo.RBStbpacanu.pan_valid = 1) AND (dbo.RBStbpacanu.dep_codigo = @dep_codigo) AND 
												  (dbo.RBStbpacanu.pan_anio = @pan_anio) AND (dbo.RBStbpartidas.par_activado = 1)
							ORDER BY dbo.RBStbpacanu.codigo_cl_inter
				end
			else
			begin
			
				SELECT     dbo.RBStbpacanu.pan_id, dbo.RBStbtipcompra.tic_descripcion, dbo.RBStbpacanu.codigo_cl_inter, substring(dbo.RBStbpac.nombre_cl_inter,1,200) as nombre_cl_inter, dbo.RBStbpacanu.pan_deprod, 
									  dbo.RBStbpacanu.pan_cantidad
				FROM         dbo.RBStbpacanu INNER JOIN
									  dbo.RBStbtipcompra ON dbo.RBStbpacanu.tic_codigo = dbo.RBStbtipcompra.tic_codigo INNER JOIN
									  dbo.RBStbpac ON dbo.RBStbpacanu.secuencia = dbo.RBStbpac.secuencia
				WHERE     (dbo.RBStbpacanu.pan_activado = 1) AND (dbo.RBStbpacanu.pan_valid = 0) AND (dbo.RBStbpacanu.dep_codigo = @dep_codigo)  AND 
									  (dbo.RBStbpacanu.pan_anio = @pan_anio)
				order by dbo.RBStbpacanu.pan_deprod
			end
	end
end
go

