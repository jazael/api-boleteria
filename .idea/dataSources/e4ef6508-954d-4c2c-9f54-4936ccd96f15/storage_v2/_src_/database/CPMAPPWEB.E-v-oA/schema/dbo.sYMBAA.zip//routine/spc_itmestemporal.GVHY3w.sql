CREATE PROCEDURE [dbo].[spc_itmestemporal]
@usr_codigo as smallint
AS
SELECT   dbo.RBStbdetord_temporal.tem_codigo, dbo.RBStbpac.nombre_cl_inter, ite_detalle,CAST(dbo.RBStbdetord_temporal.det_cantidad AS decimal(10,2)) 
                      AS det_cantidad
FROM         dbo.RBStbdetord_temporal INNER JOIN
                      dbo.RBStbpac ON dbo.RBStbdetord_temporal.ite_secuencia = dbo.RBStbpac.secuencia
WHERE     (dbo.RBStbdetord_temporal.usr_codigo = @usr_codigo)
ORDER BY RBStbpac.nombre_cl_inter
go

