create procedure spc_confil
@per_id as numeric(18,0)
as
declare @reg_nombres as nvarchar(100)
declare @reg_apellidos as nvarchar(100)
declare @reg_contacto as nvarchar(80)
declare @reg_fecha as smalldatetime
declare @reg_codp as nchar(15)
declare @cedula as nvarchar(10)
declare @reg_id as numeric(18,0)
declare @registro table(reg_id numeric(18,0),reg_cedula nvarchar(10),reg_nombres  nvarchar(100),reg_apellidos nvarchar(100),reg_contacto nvarchar(80),reg_fecha smalldatetime,reg_codp  nchar(15))
declare detalle cursor for SELECT distinct reg_cedula FROM CMOtbregistro WHERE reg_activado = 1 AND (per_id = @per_id) 
OPEN detalle
FETCH NEXT FROM detalle
INTO @cedula
WHILE @@FETCH_STATUS = 0
BEGIN 
select @reg_id= reg_id,@reg_nombres=reg_nombres, @reg_apellidos=reg_apellidos,@reg_contacto=reg_contacto,@reg_fecha=reg_fecha,@reg_codp=reg_codp 
from CMOtbregistro where reg_id=(select MAX(reg_id) from CMOtbregistro where reg_cedula=@cedula and per_id=@per_id)

insert @registro(reg_id,reg_cedula,reg_nombres ,reg_apellidos ,reg_contacto ,reg_fecha ,reg_codp)
values(@reg_id,@cedula,@reg_nombres ,@reg_apellidos ,@reg_contacto ,@reg_fecha ,@reg_codp)
FETCH NEXT FROM detalle
INTO @cedula
END	

CLOSE detalle
DEALLOCATE detalle

select * from @registro
order by reg_nombres
go

