create PROCEDURE [dbo].[spd_detord_temporal]
	
	@parametro as int,
	@tem_codigo as int,
	@usr_codigo as smallint
AS

if @parametro= 0
Begin
delete RBStbdetord_temporal  Where  (det_activado = 1) and (usr_codigo = @usr_codigo) 
End
else 
 if @parametro= 1
 Begin
	delete RBStbdetord_temporal  Where  (det_activado = 1) and (tem_codigo = @tem_codigo) 

 End
go

