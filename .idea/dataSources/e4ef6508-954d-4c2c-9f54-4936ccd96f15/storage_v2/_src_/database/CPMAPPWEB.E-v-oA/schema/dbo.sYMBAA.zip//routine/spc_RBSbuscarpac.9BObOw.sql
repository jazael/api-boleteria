
CREATE procedure [dbo].[spc_RBSbuscarpac]
@buscar nvarchar(50),
@opcion tinyint =0
as
declare @anio as integer
set @anio=YEAR(GETDATE())
if substring(@buscar,1,1)='1' or substring(@buscar,1,1)='2'or substring(@buscar,1,1)='3'or substring(@buscar,1,1)='4'or substring(@buscar,1,1)='5'or substring(@buscar,1,1)='6'or substring(@buscar,1,1)='7'or substring(@buscar,1,1)='8' or substring(@buscar,1,1)='9' or substring(@buscar,1,1)='0' 
begin
	if @opcion=0
		begin
		
			--select secuencia,codigo_cl_inter, dbo.RBStbpac.codigo_cl_inter_padre, nombre_cl_inter from dbo.RBStbpac inner join (SELECT DISTINCT  codigo_cl_inter_padre
			--FROM         dbo.RBStbpac WHERE     (codigo_cl_inter LIKE '%'+rtrim(@buscar)+'%') AND (nivel_cl_inter = 8)) as tav on tav.codigo_cl_inter_padre=codigo_cl_inter
			--union 
			SELECT DISTINCT secuencia,codigo_cl_inter, dbo.RBStbpac.codigo_cl_inter_padre, nombre_cl_inter
			FROM         dbo.RBStbpac WHERE     (codigo_cl_inter LIKE '%'+rtrim(@buscar)+'%') AND (nivel_cl_inter = 8)and (pac_activado=1)
			order by codigo_cl_inter	
		end
		else
		begin 
			set @opcion=(select dep_depende from wftbdepartamento where dep_codigo=@opcion)
			SELECT    secuencia, codigo_cl_inter, pan_id AS codigo_cl_inter_padre, pan_deprod AS nombre_cl_inter
			FROM         dbo.RBStbpacanu
			WHERE     (pan_activado = 1) AND (pan_anio = @anio) AND (codigo_cl_inter LIKE '%' + RTRIM(@buscar) + '%') AND (pan_valid = 1) AND (dep_codigo = @opcion)
			ORDER BY codigo_cl_inter
		end
end
else
begin
	if @opcion=0
		begin
			--select secuencia,codigo_cl_inter, dbo.RBStbpac.codigo_cl_inter_padre, nombre_cl_inter from dbo.RBStbpac inner join (SELECT DISTINCT  codigo_cl_inter_padre
			--FROM         dbo.RBStbpac WHERE     (nombre_cl_inter LIKE '%'+rtrim(@buscar)+'%') AND (nivel_cl_inter = 8)) as tav on tav.codigo_cl_inter_padre=codigo_cl_inter
			--union 
			SELECT DISTINCT secuencia,codigo_cl_inter, dbo.RBStbpac.codigo_cl_inter_padre, nombre_cl_inter
			FROM         dbo.RBStbpac WHERE     (nombre_cl_inter LIKE '%'+rtrim(@buscar)+'%') AND (nivel_cl_inter = 8)and (pac_activado=1)
			order by codigo_cl_inter
		end
		else
		begin
			set @opcion=(select dep_depende from wftbdepartamento where dep_codigo=@opcion)
			SELECT    secuencia, codigo_cl_inter, pan_id AS codigo_cl_inter_padre, pan_deprod AS nombre_cl_inter
			FROM         dbo.RBStbpacanu
			WHERE     (pan_activado = 1) AND (pan_anio = @anio) AND (pan_deprod LIKE '%' + RTRIM(@buscar) + '%') AND (pan_valid = 1) AND (dep_codigo = @opcion)
			ORDER BY codigo_cl_inter
		end
end
go

