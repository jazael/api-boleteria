CREATE VIEW dbo.PAC
AS
SELECT        TOP (100) PERCENT dbo.RBStbpacanu.pan_anio, dbo.RBStbpartidas.par_partida, dbo.RBStbpacanu.codigo_cl_inter, dbo.RBStbtipcompra.tic_descripcion, SUBSTRING(dbo.RBStbpacanu.pan_deprod, 1, 200) AS pan_deprod, 
                         dbo.RBStbpacanu.pan_cantidad, dbo.RBStbmedida.med_descripcion, dbo.RBStbpacanu.pan_costo, CASE WHEN dbo.RBStbpacanu.pan_c1 = 1 THEN 'S' ELSE '' END AS c1, 
                         CASE WHEN dbo.RBStbpacanu.pan_c2 = 1 THEN 'S' ELSE '' END AS c2, CASE WHEN dbo.RBStbpacanu.pan_c3 = 1 THEN 'S' ELSE '' END AS c3, dbo.RBStbpacanu.pan_tprodu, dbo.RBStbpacanu.pan_catalogo, 
                         dbo.RBStbProCompras.prc_descripcion, dbo.RBStbpacanu.pan_fbid, dbo.RBStbpacanu.pan_fbidpro, dbo.RBStbpacanu.pan_fbidcod, dbo.RBStbpacanu.pan_regimen, 
                         CASE WHEN dbo.RBStbpacanu.pan_tipg = 'GI' THEN 'PROYECTO DE INVERSION' ELSE 'GASTO CORRIENTE' END AS Expr1
FROM            dbo.RBStbpacanu INNER JOIN
                         dbo.RBStbtipcompra ON dbo.RBStbpacanu.tic_codigo = dbo.RBStbtipcompra.tic_codigo INNER JOIN
                         dbo.RBStbmedida ON dbo.RBStbpacanu.med_codigo = dbo.RBStbmedida.med_codigo INNER JOIN
                         dbo.RBStbpartidas ON dbo.RBStbpacanu.par_codigo = dbo.RBStbpartidas.par_codigo INNER JOIN
                         dbo.wftbdepartamento ON dbo.RBStbpacanu.dep_codigo = dbo.wftbdepartamento.dep_codigo INNER JOIN
                         dbo.RBStbProCompras ON dbo.RBStbpacanu.prc_codigo = dbo.RBStbProCompras.prc_codigo
WHERE        (dbo.RBStbpacanu.pan_activado = 1) AND (dbo.RBStbpacanu.pan_anio = '2019') AND (dbo.RBStbpacanu.pan_valid = 1)
ORDER BY pan_deprod
go

