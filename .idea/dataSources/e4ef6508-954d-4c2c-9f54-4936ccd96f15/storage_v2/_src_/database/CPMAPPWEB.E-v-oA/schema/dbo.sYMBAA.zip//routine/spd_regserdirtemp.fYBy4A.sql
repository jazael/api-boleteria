CREATE PROCEDURE spd_regserdirtemp
--@rri_id numeric(18,0),
--@emp_codigo smallint
@rdt_id numeric(18,0)
AS
Delete RRDtbserdirtemp where rdt_id=@rdt_id --and emp_codigo=@emp_codigo

