CREATE procedure spc_apwrActividadesverificardet
				
@rec_id numeric(18,0)
AS

SELECT  Distinct rar_id,emp_apellido+' '+emp_nombre AS Servidor,
rri.rri_ninforme,rri.rri_alcance,rec.rec_recomendacion,rar_fechaini,rar_fechafin,rar_actividad,rar_estado,rar_motivo,rar_terminada
FROM RItbinforme AS rri Inner Join RRItbrecomendacion AS rec ON rri.rri_Id=rec.rri_id
Inner Join RARTBActividad rar ON rar.rec_id=rec.rec_id 
Inner Join wftbusuario AS usr ON usr.usr_codigo=rar.usr_codigo
Inner Join CPMRRHH.dbo.rhtbempleado AS emp ON emp.emp_codigo=usr.emp_codigo 
where rri.rri_activado=1 and rec.rec_activado=1 and rar.rar_activado=1 and rec.rec_id=@rec_id order by 9,2,6,8
go

