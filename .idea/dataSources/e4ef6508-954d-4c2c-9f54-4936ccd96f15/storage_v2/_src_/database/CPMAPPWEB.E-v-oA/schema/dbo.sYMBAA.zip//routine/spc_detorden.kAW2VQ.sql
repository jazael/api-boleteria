create procedure spc_detorden
@cad_codigo as int,
@cod_usr as smallint,
@host nchar(20),
@adress nchar(20)
AS

exec spi_auditoriaP @cod_usr,'spc_detorden','DETTALLE DE ORDENES',@host ,@adress

SELECT     dbo.RBStbdetord.ite_codigo, dbo.RBStbdetord.det_cantidad, dbo.RBStbdetord.det_detalle, SUBSTRING(dbo.RBStbpac.nombre_cl_inter, 1, 80) 
                      AS nombre_cl_inter
FROM         dbo.RBStbdetord INNER JOIN
                      dbo.RBStbpac ON dbo.RBStbdetord.ite_secuencia = dbo.RBStbpac.secuencia
WHERE     (dbo.RBStbdetord.cad_codigo = @cad_codigo)
go

