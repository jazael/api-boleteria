create procedure spc_registro
@reg_cedula varchar(10)
as
declare @bit as tinyint
set @bit=0
if not exists(select reg_cedula from CMOtbregistro inner join CMOtbperfiles on cmotbperfiles.per_id=CMOtbregistro.per_id where reg_cedula=@reg_cedula and per_activado=1 and reg_activado=1)
begin 
set @bit=1
end
select @bit as bit
go

