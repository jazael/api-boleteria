create procedure [dbo].[spc_tusuario]
@tusu_codigo tinyint
as
if @tusu_codigo=0
begin
	SELECT     tusu_codigo, tusu_descripcion
	FROM         dbo.wftbtusuario
	WHERE     (tusu_activado = 1) 
end
else
begin
	SELECT     tusu_codigo, tusu_descripcion
	FROM         dbo.wftbtusuario
	WHERE     (tusu_activado = 1) and tusu_codigo <> 0
end
go

