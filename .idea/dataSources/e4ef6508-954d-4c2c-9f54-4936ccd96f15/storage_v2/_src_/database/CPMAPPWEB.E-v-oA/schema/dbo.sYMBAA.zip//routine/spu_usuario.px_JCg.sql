
CREATE procedure [dbo].[spu_usuario]
@dep_codigo tinyint,
@usr_user varchar(50),
@usr_password varchar(50),
@usr_apellido varchar(50),
@usr_nombre varchar(50),
@tusu_codigo tinyint,
@usr_correo varchar(50),
@usr_activado bit,
@cod_usr smallint,
@host nchar(20),
@adress nchar(20)
as 
declare @usr_codigo as smallint
declare @men as nvarchar(50)
set @men ='Proceso Completado'
select @usr_codigo=usr_codigo from wftbusuario where usr_user=@usr_user
--if exists (select usr_codigo from wftbproc_usr where usr_codigo=@usr_codigo ) 
--begin
--set @usr_activado=1
--set @men ='No se puede realizar acción usuario con asignación'
--end
--if exists (select plan_responsable from wftbplantilla where plan_responsable=@usr_codigo ) 
--begin
--set @usr_activado=1
--set @men ='No se puede realizar acción usuario con asignación'
--end

--if exists(SELECT     dbo.wftbproc_usr.usr_codigo
--FROM         dbo.wftbpro_control INNER JOIN
--                      dbo.wftbproc_usr ON dbo.wftbpro_control.pct_codigo = dbo.wftbproc_usr.pct_codigo INNER JOIN
--                      dbo.wftbplantilla INNER JOIN
--                      dbo.wftbplantilla_tarea ON dbo.wftbplantilla.plan_codigo = dbo.wftbplantilla_tarea.plan_codigo ON 
--                      dbo.wftbpro_control.plt_id = dbo.wftbplantilla_tarea.plt_id
--WHERE     (dbo.wftbproc_usr.usr_codigo = @usr_codigo))
--begin
--set @usr_activado=1
--set @men ='No se puede realizar acción usuario con asignación'
--end

if @usr_codigo <>1
begin
update wftbusuario set
dep_codigo=@dep_codigo,
usr_password=@usr_password,
usr_apellido=@usr_apellido,
usr_nombre=@usr_nombre,
tusu_codigo=@tusu_codigo,
usr_correo=@usr_correo,
usr_activado=@usr_activado
where usr_codigo=@usr_codigo
exec spi_auditoriaP @cod_usr,'spu_usuario','Edición de usuarios',@host ,@adress
delete wftbuserdepart
where usr_codigo=@usr_codigo
end
select @usr_codigo as codigo,@men as men

go

