CREATE Procedure spc_apwrinforme 
@rri_Id numeric(18,0)
as
SELECT rri_Id,inf.emi_id,emi_emitida,rri_noficnoti,rri_femisioninf,rri_frecepcioninf,rri_ninforme,rri_faprobacion,rri_finicio,rri_ffin,rri_alcance,rri_activado,rri_nominforme,rri_informe
FROM RItbinforme inf inner join REtbemitido emi on emi.emi_id=inf.emi_id where rri_Id=@rri_Id order by rri_faprobacion desc
go

