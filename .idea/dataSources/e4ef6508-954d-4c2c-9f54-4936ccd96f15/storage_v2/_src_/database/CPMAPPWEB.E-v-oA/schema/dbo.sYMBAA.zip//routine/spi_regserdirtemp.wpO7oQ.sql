CREATE PROCEDURE spi_regserdirtemp
@rri_id numeric(18,0),
----@emp_codigo smallint
@cargo varchar(100),
@usr_codigo smallint
as
Declare @rdt_id smallint
Select @rdt_id =isnull(max(rdt_id),0)+1 from RRDtbserdirtemp

--declare @cargo varchar(100)
--Set @cargo='356-d'
Declare @car_codigo varchar(100)
Set @car_codigo=''
Declare @tamaño tinyint
Declare @i Smallint
set @i=0
Declare @caracter char(1)
----Set @cod_cargo=str(@cod_cargo)
--set @cod_cargo=len('ddd')
Set @tamaño=len(@cargo)
--print @tamaño
while (@i<@tamaño)
begin
Set @i=@i+1
set @caracter=(Substring(@cargo, @i, 1))
if(@caracter='-')
begin
set @i=@tamaño
end
else
begin
set @car_codigo=@car_codigo+@caracter
end
--print @cod_cargo
end
print @car_codigo


insert into RRDtbserdirtemp(rdt_id,rri_id,car_codigo,usr_codigo) values(@rdt_id,@rri_id,@car_codigo,@usr_codigo)
go

