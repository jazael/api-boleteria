CREATE PROCEDURE spi_REAtbevidencia
@rar_id numeric(18,0),
@rri_id numeric(18,0),
@rec_id numeric(18,0),
@usr_codigo smallint,
@red_descripcion VARCHAR(MAX), 
@red_nomevidencia VARCHAR(250), 
@valor tinyint, 
@red_evidencia IMAGE
AS

Declare @red_id NUMERIC (18,0)
Select @red_id =isnull(max(red_id),0)+1 from  REAtbevidenciadet

IF(@valor=0)
BEGIN
Declare @rev_id NUMERIC (18,0)
Select @rev_id =isnull(max(rev_id),0)+1 from  REAtbevidencia
Insert Into REAtbevidencia(rev_id,rar_id,rri_id,rec_id,rev_fechaingreso,usr_codigo,rev_estado,rev_activado)
Values (@rev_id,@rar_id,@rri_id,@rec_id,GETDATE(),@usr_codigo,'0','1')
END

IF(@valor>0)
BEGIN
Select @rev_id =(Select max(rev_id) AS rev_id  from  REAtbevidencia where rri_id=@rri_id and rec_id=@rec_id and usr_codigo=@usr_codigo and rar_id=@rar_id)
--Select @rev_id =(Select max(rev_id) AS rev_id  from  REAtbevidencia where rri_id=1 and rec_id=1 and usr_codigo=93 and rar_id=5)
--PRINT @rev_id
END
Insert Into REAtbevidenciadet(red_id,rev_id,red_descripcion,red_nomevidencia,red_evidencia,red_estado,red_motivo)
Values (@red_id,@rev_id,@red_descripcion,@red_nomevidencia,@red_evidencia,'0',' ')

--Select max(rev_id) AS rev_id  from  REAtbevidencia where rri_id=3 and rec_id=1 and usr_codigo=93
go

