CREATE PROCEDURE spc_regactitemp 
@rri_id numeric(18,0),
@rec_id numeric(18,0),
@usr_codigo smallint
AS
Select * from dbo.RARTBActividadTemp where rri_id=@rri_id and rec_id=@rec_id and usr_codigo=@usr_codigo

