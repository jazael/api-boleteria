CREATE procedure [dbo].[spc_regapel]
@reg_id int 
as
		if not exists( select reg_id from CMOtbapela where reg_id=@reg_id and ape_activado=1)
			begin	
			SELECT     per_denominacion,reg_cedula, reg_nombres, reg_apellidos, reg_contacto, '0' as ban
			FROM       dbo.CMOtbregistro INNER JOIN CMOtbperfiles ON dbo.CMOtbregistro.per_id=CMOtbperfiles.per_id WHERE (reg_id = @reg_id) 

end
 else
 begin 
 SELECT    '' as per_denominacion,'' as reg_cedula, '' as reg_nombres, '' as reg_apellidos, '' as reg_contacto, '1' as ban
 end
go

