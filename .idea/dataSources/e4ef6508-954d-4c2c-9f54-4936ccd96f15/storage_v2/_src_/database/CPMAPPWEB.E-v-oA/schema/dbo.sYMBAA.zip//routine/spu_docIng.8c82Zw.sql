

CREATE procedure [dbo].[spu_docIng]
@tra_id	int,
@doc_pdf	image	
as

update cdtbdocumento set
doc_activado=0
where tra_id=@tra_id and doc_rec=0 and doc_activado=1

insert cdtbdocumento(tra_id,doc_pdf,doc_rec,doc_activado,doc_tipe)
		values(@tra_id,@doc_pdf,0,1,1)


go

