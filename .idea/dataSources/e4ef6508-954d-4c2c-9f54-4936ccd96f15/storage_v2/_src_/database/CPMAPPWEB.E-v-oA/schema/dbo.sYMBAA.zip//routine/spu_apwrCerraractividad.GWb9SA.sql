CREATE Procedure spu_apwrCerraractividad
@rar_id numeric(18,0),
@rar_terminada bit
AS
Update RARTBActividad Set rar_terminada=@rar_terminada Where rar_Id=@rar_id

Declare @actividades_abiertas tinyint
Declare @recomendaciones_abiertas tinyint

Set @actividades_abiertas=(Select count(rec_id) rec_id from RARTBActividad where rec_id=(Select rec_id from RARTBActividad where rar_id=@rar_id) and rar_terminada=0)
If(@actividades_abiertas=0)--Si ya no hay actividades abiertas para esa recomendación, cerramos la recomendación concernientes a todas las actividades.
Begin
Update RRItbrecomendacion Set rec_terminada=1 where  rec_id=(Select rec_id from RARTBActividad where rar_id=@rar_id)
End

--Si ya no existen recomendaciones abiertas se procede a cerrar el informe
Set @recomendaciones_abiertas=(Select count(rri_id) rri_id from RRItbrecomendacion where rri_id=(Select rri_id from RARTBActividad where rar_id=@rar_id) and rec_terminada=0)
If(@recomendaciones_abiertas=0)--Si ya no hay actividades abiertas para esa recomendación, cerramos la recomendación concernientes a todas las actividades.
Begin
Update RItbinforme Set rri_terminado=1 where rri_Id=(Select rri_id from RARTBActividad where rar_id=@rar_id)
End
go

