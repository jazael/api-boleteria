Create Procedure spc_apwrinformeAsigUsu
@usr_codigo smallint 
AS
SELECT DISTINCT rec.rri_id, rin.rri_ninforme FROM RRItbrecomendacion AS rec 
INNER JOIN RItbinforme AS rin ON rec.rri_id = rin.rri_Id 
INNER JOIN RRDtbserres AS res ON rec.rec_id = res.rec_id 
WHERE (rin.rri_activado = 1) AND (rec.rec_activado = 1) AND (res.emp_codigo =(Select emp_codigo from wftbusuario where usr_codigo= @usr_codigo))
ORDER BY rec.rri_id
go

