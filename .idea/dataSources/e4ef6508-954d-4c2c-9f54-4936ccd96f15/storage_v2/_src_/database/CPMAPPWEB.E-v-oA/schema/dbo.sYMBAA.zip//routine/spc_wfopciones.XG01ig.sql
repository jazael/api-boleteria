


CREATE PROCEDURE [dbo].[spc_wfopciones]
@usr_codigo smallint,
@opt tinyint	
AS
BEGIN
if @opt<>99
begin
SELECT     dbo.wftbopciones.opt_codigo, dbo.wftbopciones.opt_descipcion, dbo.wftbopciones.opt_posicion, dbo.wftbopciones.opt_padre, 
                      dbo.wftbopciones.opt_icono, dbo.wftbopciones.opt_activado, dbo.wftbopciones.opt_url
FROM         dbo.wftbopciones INNER JOIN
                      dbo.wftbopcion_usuario ON dbo.wftbopciones.opt_codigo = dbo.wftbopcion_usuario.opt_codigo
WHERE     (dbo.wftbopciones.opt_activado = 1) AND (dbo.wftbopcion_usuario.usr_codigo = @usr_codigo) and wftbopcion_usuario.opu_activado=1
			AND (dbo.wftbopciones.mod_codigo = @opt)
ORDER BY dbo.wftbopciones.opt_orden
end
else
begin
SELECT DISTINCT  dbo.wftbmodulos.mod_codigo
FROM         dbo.wftbopciones INNER JOIN
                      dbo.wftbopcion_usuario ON dbo.wftbopciones.opt_codigo = dbo.wftbopcion_usuario.opt_codigo INNER JOIN
                      dbo.wftbmodulos ON dbo.wftbopciones.mod_codigo = dbo.wftbmodulos.mod_codigo
WHERE     (dbo.wftbopciones.opt_activado = 1) AND (dbo.wftbopcion_usuario.usr_codigo = @usr_codigo) AND (dbo.wftbopcion_usuario.opu_activado = 1)
END
end

go

