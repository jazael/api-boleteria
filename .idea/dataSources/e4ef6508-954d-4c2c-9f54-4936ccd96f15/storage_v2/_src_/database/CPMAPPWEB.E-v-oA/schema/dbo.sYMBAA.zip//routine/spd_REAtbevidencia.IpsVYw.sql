CREATE Procedure spd_REAtbevidencia
@red_id numeric(18,0),
@valor tinyint
AS

IF(@valor=1)--Si en el Grid de evidencias solo hay un solo registro a eliminar, también eliminará el registro de la tabla principal
Begin
Delete REAtbevidencia where rev_id=(Select rev_id from REAtbevidenciadet where red_id=@red_id)
end
Delete REAtbevidenciadet where red_id=@red_id
go

