CREATE procedure [dbo].[spc_basCon]
@opcion tinyint = 0
as
if @opcion=1
	begin
		SELECT     per_denominacion, per_vacantes, per_ciudad, per_hasta, per_publicado ,per_id
		FROM         dbo.CMOtbperfiles
		WHERE      (per_activado = 1)
		order by per_id
	end
	else	
		begin
			if @opcion=2
				begin 
				--SELECT     CAST(per_id AS nvarchar(10)) + ' | ' + per_denominacion AS denomina, per_id
				SELECT      per_denominacion AS denomina, per_id
				FROM         dbo.CMOtbperfiles
				WHERE     (per_publicado = 1) AND (per_activado = 1) AND (per_ejecutado = 0)
				ORDER BY per_id
				end
				else
				begin
					IF @opcion=3
					begin
					--SELECT     CAST(per_id AS nvarchar(10)) + ' | ' + per_denominacion as per_denominacion,   per_id
					SELECT      per_denominacion as per_denominacion,   per_id
					FROM         dbo.CMOtbperfiles
					WHERE     (per_publicado = 1) AND (per_activado = 1) AND (per_hasta >= GETDATE()) AND (per_desde <= GETDATE())
					order by per_id
					end
					else
					begin
					SELECT     per_denominacion, per_vacantes, per_ciudad,  per_hasta, per_id
					FROM         dbo.CMOtbperfiles
					WHERE     (per_publicado = 1) AND (per_activado = 1) AND (per_hasta >= GETDATE()) AND (per_desde <= GETDATE())
					order by per_id
					end
				end
		end
go

