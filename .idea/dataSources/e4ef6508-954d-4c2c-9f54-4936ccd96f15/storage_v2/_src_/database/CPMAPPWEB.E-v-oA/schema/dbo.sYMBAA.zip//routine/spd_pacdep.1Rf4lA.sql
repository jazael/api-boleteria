
CREATE PROCEDURE spd_pacdep
	@pan_id as numeric(18,0),
	@usr_codigo as smallint
AS

update RBStbpacanu set 
pan_valid=0
where pan_id=@pan_id
go

