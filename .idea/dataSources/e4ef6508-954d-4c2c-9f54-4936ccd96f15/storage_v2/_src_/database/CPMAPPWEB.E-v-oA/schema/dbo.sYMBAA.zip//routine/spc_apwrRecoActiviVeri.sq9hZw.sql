CREATE PROCEDURE spc_apwrRecoActiviVeri--Solo muestra las recomendaciones que tengan actividades registradas y Habilitadas
@rri_id numeric(18,0),
@usr_codigo smallint
AS

Select distinct rec.rec_Id,rec_recomendacion from RRItbrecomendacion AS rec inner join RARTBActividad AS rac
on rec.rec_id=rac.rec_id Where rar_estado=1 and rac.rri_id=@rri_id and usr_codigo=@usr_codigo

