CREATE procedure [dbo].[spc_partidas]
@dep_codigo as tinyint
as
declare @pro_codigo as tinyint
declare @anio as  smallint
set @anio= (select an_valor from RBStbanios where an_activado=1)
select @pro_codigo=pro_codigo from wftbdepartamento where dep_codigo=@dep_codigo
if @anio>='2020'
begin
SELECT   par_codigo, par_partida + ' - ' + par_detalle + ' - ' + convert(nvarchar(20),par_monto ) AS detalle
FROM         dbo.RBStbpartidas
WHERE     (pro_codigo = @pro_codigo) and par_activado=1 and par_anio=@anio
ORDER BY par_codigo
end
else
begin
SELECT   par_codigo, SUBSTRING(par_partida, 25, 32) + ' - ' + par_detalle + ' - ' + convert(nvarchar(20),par_monto ) AS detalle
FROM         dbo.RBStbpartidas
WHERE     (pro_codigo = @pro_codigo) and par_activado=1 and par_anio=@anio
ORDER BY par_codigo
end

go

