CREATE PROCEDURE spc_apwrServidorActivi--Solo muestra los servidores que tengan actividades registradas
@rri_id numeric(18,0),
@rec_id numeric(18,0)
AS

Select distinct emp.emp_codigo,emp_apellido+' '+emp_nombre As Servidor from CPMRRHH.dbo.rhtbempleado emp 
inner join wftbusuario usu ON emp.emp_codigo=usu.emp_codigo 
inner join RARTBActividad AS rac ON rac.usr_codigo=usu.usr_codigo where rri_id=@rri_id and rec_id=@rec_id
go

