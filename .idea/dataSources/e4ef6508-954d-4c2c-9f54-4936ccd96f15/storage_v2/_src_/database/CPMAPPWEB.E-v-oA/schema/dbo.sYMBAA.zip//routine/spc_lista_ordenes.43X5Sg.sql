
CREATE PROCEDURE [dbo].[spc_lista_ordenes]
@usr_codigo as smallint,
@dep_codigo as int,
@cad_fecha as datetime,
@cad_fecha_hasta as datetime,
@activado as bit
	
AS
SELECT DISTINCT 
                 TOP (100) PERCENT dbo.RBStbcadord.cad_codigo, dbo.RBStbcadord.cad_fecha,cad_observacion, dbo.wftbdepartamento.dep_nombre, dbo.RBStbcadord.usr_codigo, 
                      dbo.RBStbcadord.dep_codigo
FROM         dbo.RBStbdetord INNER JOIN
                      dbo.RBStbcadord ON dbo.RBStbdetord.cad_codigo = dbo.RBStbcadord.cad_codigo INNER JOIN
                      dbo.wftbdepartamento ON dbo.RBStbcadord.dep_codigo = dbo.wftbdepartamento.dep_codigo INNER JOIN
                      dbo.RBStbpac ON dbo.RBStbdetord.ite_secuencia = dbo.RBStbpac.secuencia
WHERE     ( (dbo.RBStbcadord.dep_codigo = @dep_codigo) AND (dbo.RBStbcadord.cad_fecha BETWEEN 
                      @cad_fecha AND @cad_fecha_hasta) and RBStbcadord.cad_activado=@activado and det_activado=@activado)
GROUP BY dbo.RBStbcadord.cad_codigo, dbo.RBStbcadord.cad_fecha, dbo.wftbdepartamento.dep_nombre, dbo.RBStbcadord.usr_codigo, 
                      dbo.RBStbcadord.dep_codigo, dbo.wftbdepartamento.dep_nombre,cad_observacion
ORDER BY dbo.RBStbcadord.cad_fecha
go

