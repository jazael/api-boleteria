
create PROCEDURE [dbo].[spi_temmen]
	@usr_codigo  smallint,
	@med_orden  nvarchar(10),
	@med_factura nvarchar(10),
	@med_base float
AS
declare @men_codigo as smallint
select @men_codigo=isnull(max(men_codigo),0)+1 from RBStbtemmen where usr_codigo = @usr_codigo
insert into RBStbtemmen (men_codigo, usr_codigo,med_orden, med_factura,med_base)
values(@men_codigo, @usr_codigo,@med_orden, @med_factura,@med_base)


go

