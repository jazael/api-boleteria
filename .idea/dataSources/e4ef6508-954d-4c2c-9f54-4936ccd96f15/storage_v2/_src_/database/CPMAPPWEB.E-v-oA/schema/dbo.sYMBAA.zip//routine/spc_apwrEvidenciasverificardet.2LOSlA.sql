CREATE procedure spc_apwrEvidenciasverificardet
@rec_id numeric(18,0)
AS

SELECT  Distinct red_id,rar.rar_id,emp_apellido+' '+emp_nombre AS Servidor,
rar_fechaini,rar_fechafin,rar_actividad,red_descripcion,red_nomevidencia,red_estado,red_motivo
FROM RItbinforme AS rri Inner Join RRItbrecomendacion AS rec ON rri.rri_Id=rec.rri_id
Inner Join RARTBActividad rar ON rar.rec_id=rec.rec_id 
Inner Join REAtbevidencia rev ON rar.rar_Id=rev.rar_id
Inner Join REAtbevidenciadet red ON rev.rev_id=red.rev_id
Inner Join wftbusuario AS usr ON usr.usr_codigo=rar.usr_codigo
Inner Join CPMRRHH.dbo.rhtbempleado AS emp ON emp.emp_codigo=usr.emp_codigo 
where rar_estado=1 and rri.rri_activado=1 and rec.rec_activado=1 and rar.rar_activado=1 and rec.rec_id=@rec_id order by 9,3,4,6,7
go

