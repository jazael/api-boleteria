CREATE procedure [dbo].[spc_usuario]
@usr_user varchar(50),
@cod_usr smallint,
@host nchar(20),
@adress nchar(20)
as
	exec spi_auditoriaP @cod_usr,'spc_usuario','Consulta de Usuarios',@host ,@adress
SELECT     dep_codigo,usr_codigo, usr_user, usr_password, usr_apellido, usr_nombre,tusu_codigo, usr_correo, usr_activado
FROM         dbo.wftbusuario where usr_user=@usr_user


go

