create procedure spd_orden
@cad_codigo as int,
@cod_usr as smallint,
@host nchar(20),
@adress nchar(20)
AS

exec spi_auditoriaP @cod_usr,'spd_orden','Anulación de ordenes',@host ,@adress

update dbo.RBStbdetord set 
det_activado=0
where cad_codigo=@cad_codigo

update dbo.RBStbcadord set 
cad_activado=0
where cad_codigo=@cad_codigo

