CREATE procedure [dbo].[spc_selecdoc]
@tra_id int,
@opcion tinyint
as
if @opcion=1
begin
	SELECT     tra_codigo, tra_fecha, tra_tdoc, dep_codigo, tra_benf, tra_asunto
	FROM         dbo.CDtbtramite
	WHERE     (tra_id = @tra_id) AND (tra_activado = 1)
end
if @opcion=2
begin
	SELECT     tra_codigo, tra_docenv, tra_enviado, tra_fechaenv, tra_observa
FROM         dbo.CDtbtramite
WHERE     (tra_id = @tra_id) AND (tra_activado = 1)
end
go

