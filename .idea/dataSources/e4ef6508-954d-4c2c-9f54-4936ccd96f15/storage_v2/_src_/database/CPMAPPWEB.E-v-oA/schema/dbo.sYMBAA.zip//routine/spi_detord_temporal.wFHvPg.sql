CREATE PROCEDURE [dbo].[spi_detord_temporal]
	@ite_codigo  smallint,
	@det_cantidad  smallmoney,
	@ite_detalle nchar(200),
	@usr_codigo smallint,
	@opcion tinyint =0
AS
declare @det_pac as int
declare @tem_codigo as int
declare @codigochar as varchar(50)
select @tem_codigo=isnull(max(tem_codigo),0)+1 from RBStbdetord_temporal where usr_codigo = @usr_codigo
set @det_pac=0
if @opcion=1
begin
	set @det_pac=@ite_codigo
	set @ite_codigo=(Select secuencia from  RBStbpacanu where pan_id=@det_pac)
end
set @codigochar=(select codigo_cl_inter from RBStbpac WHERE secuencia=@ite_codigo)

insert into RBStbdetord_temporal (tem_codigo, ite_secuencia,ite_codigo, det_cantidad,ite_detalle,det_activado,usr_codigo,det_pac)
values(@tem_codigo, @ite_codigo, @codigochar,@det_cantidad,@ite_detalle, 1, @usr_codigo,@det_pac)


go

