create PROCEDURE [dbo].[spi_regcap]
@reg_cedula	nchar(10),	
@reg_nombre	nvarchar(50),	
@reg_apellido	nvarchar(50),	
@cod_canton	smallint,	
@cod_parroquia	smallint,	
@eve_organiza	nvarchar(200),	
@eve_cargo	nvarchar(80),	
@eve_mail	nvarchar(50)	
AS

insert CPPRegistro(reg_cedula,reg_nombre,reg_apellido,cod_canton,cod_parroquia,eve_organiza,eve_cargo,eve_mail,reg_fecha,reg_activado,eve_codigo)
	Values(@reg_cedula,@reg_nombre,@reg_apellido,@cod_canton,@cod_parroquia,@eve_organiza,@eve_cargo,@eve_mail,getdate(),1,1)

go

