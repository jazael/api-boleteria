CREATE PROCEDURE [dbo].[spc_CPPregcon]
@reg_cedula	nchar(10)
AS

if exists(select * from CCTcarnet where car_cedula=@reg_cedula and car_activado=1) 
	begin
	select *, dato=1 from CCTcarnet where car_cedula=@reg_cedula and car_activado=1
		
	end
else
	begin
		SELECT descripcion, dato=2 FROM cpmciudadanos.dbo.cdtbregistro WHERE cedula= @reg_cedula
	end
go

