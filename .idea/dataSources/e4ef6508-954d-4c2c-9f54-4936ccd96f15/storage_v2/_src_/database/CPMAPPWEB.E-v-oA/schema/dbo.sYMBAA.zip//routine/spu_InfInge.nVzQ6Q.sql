
create procedure [dbo].[spu_InfInge]
@tra_id int,
@tra_docenv	tinyint,
@tra_fechaenv	smalldatetime,
@tra_enviado	nvarchar(80),
@tra_observa	nvarchar(500)
as

update cdtbtramite set
tra_docenv=@tra_docenv,
tra_fechaenv=@tra_fechaenv,
tra_enviado=@tra_enviado,
tra_observa=@tra_observa
where tra_id=@tra_id


go

