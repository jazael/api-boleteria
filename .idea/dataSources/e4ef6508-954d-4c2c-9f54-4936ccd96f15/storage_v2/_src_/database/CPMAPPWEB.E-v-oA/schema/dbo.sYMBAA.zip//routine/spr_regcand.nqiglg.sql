CREATE procedure [dbo].[spr_regcand]
@reg_cedula	varchar(10)
as
SELECT     dbo.CMOtbperfiles.per_id, dbo.CMOtbperfiles.per_denominacion, dbo.CMOtbperfiles.per_ciudad, dbo.CMOtbregistro.reg_cedula, dbo.CMOtbregistro.reg_nombres, 
                      dbo.CMOtbregistro.reg_apellidos, dbo.CMOtbregistro.reg_contacto, dbo.CMOtbregistro.reg_telefono, dbo.CMOtbregistro.reg_fecha
FROM         dbo.CMOtbperfiles INNER JOIN
                      dbo.CMOtbregistro ON dbo.CMOtbperfiles.per_id = dbo.CMOtbregistro.per_id
WHERE     (CMOtbregistro.reg_activado=1)and (dbo.CMOtbregistro.reg_id =
                          (SELECT     MAX(reg_id) AS regtistro
                            FROM          dbo.CMOtbregistro AS CMOtbregistro_1
                            WHERE      (reg_cedula = @reg_cedula) and reg_activado=1))
go

