CREATE PROCEDURE spd_regserrestemp
--@rri_id numeric(18,0),
--@emp_codigo smallint
@rrt_id numeric(18,0)
AS
Delete RRDtbserrestemp where rrt_id=@rrt_id and rrt_id=@rrt_id
go

