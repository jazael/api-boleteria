CREATE Procedure spd_regactitemp
@rat_Id numeric(18,0)
/*@rri_id numeric(18,0),
@rec_id numeric(18,0),
@usr_codigo smallint*/
AS
Delete dbo.RARTBActividadTemp where rat_Id=@rat_Id and rat_id=@rat_id --and rri_id=@rri_id and rec_id=@rec_id and usr_codigo=@usr_codigo

