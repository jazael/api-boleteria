CREATE procedure [dbo].[spi_subregisE]
@inf_codigo int,	
@emp_cedula	nchar(10),
@emp_nombre	nchar(100)
as
declare @emp_cargo as nchar(40)
declare @maq_descripcion	nchar(50)
declare @maq_placa	nchar(15)
set @emp_cargo= (SELECT CPMOOPP.dbo.optbcargo.car_descripcion FROM CPMOOPP.dbo.optbempleado INNER JOIN CPMOOPP.dbo.optbcargo ON CPMOOPP.dbo.optbempleado.car_codigo = CPMOOPP.dbo.optbcargo.car_codigo WHERE (CPMOOPP.dbo.optbempleado.emp_cedula = @emp_cedula))
SELECT     @maq_placa=CPMOOPP.dbo.optbmaquinaria.maq_placa, @maq_descripcion=CPMOOPP.dbo.optbtipo_maquinaria.tip_descripcion
FROM         CPMOOPP.dbo.optbmaquinaria INNER JOIN
                      CPMOOPP.dbo.optbmaquina_empleado ON CPMOOPP.dbo.optbmaquinaria.maq_codigo = CPMOOPP.dbo.optbmaquina_empleado.maq_codigo INNER JOIN
                      CPMOOPP.dbo.optbtipo_maquinaria ON CPMOOPP.dbo.optbmaquinaria.tip_codigo = CPMOOPP.dbo.optbtipo_maquinaria.tip_codigo
WHERE     (CPMOOPP.dbo.optbmaquina_empleado.maq_operador = @emp_cedula) OR
                      (CPMOOPP.dbo.optbmaquina_empleado.maq_ayudante = @emp_cedula)
insert VSTBdatgene (inf_codigo,emp_cedula,emp_nombre,emp_cargo,maq_descripcion,maq_placa,dag_activado)
		values(@inf_codigo,@emp_cedula,@emp_nombre,@emp_cargo,@maq_descripcion,@maq_placa,1)


go

