
Create Procedure scp_apwrnumerorecomen
@rri_id numeric(18,0),
@rec_numrecomendacion  varchar(8)
AS
Select count(rec_numrecomendacion) from RRItbrecomendacion where rri_id=@rri_id and rec_numrecomendacion=@rec_numrecomendacion
go

