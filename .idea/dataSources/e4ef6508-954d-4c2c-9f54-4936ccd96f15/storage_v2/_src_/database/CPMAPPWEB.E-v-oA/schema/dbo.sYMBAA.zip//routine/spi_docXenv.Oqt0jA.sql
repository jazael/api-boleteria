
CREATE procedure [dbo].[spi_docXenv]
@tra_exid int,
@tra_numero	varchar(10),
@tra_fecha	smalldatetime,
@tra_enviado	nvarchar(80),
@tra_observacion	nvarchar(500)
as

update cdtbtramitex set
tra_numero=@tra_numero,
tra_fenvio=@tra_fecha,
tra_enviado=@tra_enviado,
tra_observacion=@tra_observacion
where tra_exid=@tra_exid


go

