
CREATE procedure spi_regcand
@reg_cedula	varchar(10),
@per_id	numeric(18, 0),	
@reg_nombres	nvarchar(100),	
@reg_apellidos	nvarchar(100),	
@reg_contacto	nvarchar(80),	
@reg_telefono	nvarchar(20),	
@reg_codp	nchar(15),
@reg_hvida	image	
as

insert CMOtbregistro(reg_cedula,per_id,reg_nombres,reg_apellidos,reg_contacto,reg_telefono,reg_fecha,reg_activado,reg_hvida,reg_codp)
values(@reg_cedula,@per_id,@reg_nombres,@reg_apellidos,@reg_contacto,@reg_telefono,GETDATE(),1,@reg_hvida,@reg_codp)
go

