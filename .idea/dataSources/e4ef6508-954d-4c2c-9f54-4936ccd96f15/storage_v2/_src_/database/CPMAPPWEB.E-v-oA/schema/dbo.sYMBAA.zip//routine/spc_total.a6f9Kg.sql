
create PROCEDURE [dbo].[spc_total]
@dep_codigo tinyint,
@pan_anio smallint
AS

SELECT     ISNULL
                          ((SELECT     SUM(pan_cantidad * pan_costo) AS total
                              FROM         dbo.RBStbpacanu
                              WHERE     (dep_codigo = @dep_codigo) AND (pan_anio = @pan_anio) AND (pan_valid = 1) AND (pan_activado = 1)), 0) AS total
go

