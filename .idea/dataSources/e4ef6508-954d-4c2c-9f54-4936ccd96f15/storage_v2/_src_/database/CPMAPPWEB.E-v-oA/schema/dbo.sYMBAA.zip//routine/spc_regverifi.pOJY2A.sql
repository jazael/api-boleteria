create  procedure spc_regverifi
@reg_cedula varchar(10)
as
declare @reg_id as numeric(18,0)
if exists(SELECT reg_cedula FROM dbo.CMOtbregistro inner join CMOtbperfiles on CMOtbregistro.per_id= CMOtbperfiles.per_id WHERE (reg_cedula = @reg_cedula) and reg_activado=1 and per_activado=1 )
begin

		
			SELECT     reg_id, reg_nombres, reg_apellidos, reg_contacto,per_denominacion, '' as ban	FROM dbo.CMOtbregistro inner join CMOtbperfiles on CMOtbregistro.per_id= CMOtbperfiles.per_id  WHERE (reg_cedula = @reg_cedula) and reg_activado=1 and per_activado=1
			
end			
else
begin
SELECT     '' as reg_id, '' as reg_nombres,'' as reg_apellidos,'' as reg_contacto,'' as per_denominacion, 'Usted no se encuentra registrado' as ban
end
go

