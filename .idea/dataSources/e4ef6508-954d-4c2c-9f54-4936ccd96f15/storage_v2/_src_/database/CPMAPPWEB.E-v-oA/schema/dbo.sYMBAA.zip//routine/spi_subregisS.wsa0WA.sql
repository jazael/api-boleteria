CREATE procedure [dbo].[spi_subregisS]
@inf_codigo int,	
@emp_cedula	nchar(10),
@fre_codigo int,
@dlab_fecha	smalldatetime,
@dlab_tipo	tinyint
as
declare @dlab_programado bit
set @dlab_programado=0

if exists(SELECT CPMOOPP.dbo.optbprogramacion.fre_fecha FROM CPMOOPP.dbo.optbprogramacion WHERE ((CPMOOPP.dbo.optbprogramacion.cod_ayudante = @emp_cedula)OR(CPMOOPP.dbo.optbprogramacion.cod_operador = @emp_cedula)) AND (CPMOOPP.dbo.optbprogramacion.fre_fecha = @dlab_fecha)
		  AND (CPMOOPP.dbo.optbprogramacion.pro_activado = 1) AND CPMOOPP.dbo.optbprogramacion.fre_codigo=@fre_codigo)
begin
set @dlab_programado=1
end

insert VSTBdiaslab(inf_codigo,emp_cedula,dlab_fecha,dlab_activado,dlab_tipo,dlab_programado)
		values(@inf_codigo,@emp_cedula,@dlab_fecha,1,@dlab_tipo,@dlab_programado)


go

