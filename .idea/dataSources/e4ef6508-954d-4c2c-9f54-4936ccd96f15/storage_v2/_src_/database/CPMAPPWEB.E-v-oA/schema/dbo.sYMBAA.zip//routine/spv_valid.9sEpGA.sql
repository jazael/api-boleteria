CREATE PROCEDURE [dbo].[spv_valid]
	@cedula nchar(10),
	@fecha smalldatetime,
	@opcion tinyint
AS
declare @mens as nvarchar(500)
set @mens='1'
if  @opcion ='1'
	begin
		if not exists( select emp_codigo from CPMOOPP.dbo.optbempleado where CPMOOPP.dbo.optbempleado.emp_codigo=@cedula and CPMOOPP.dbo.optbempleado.emp_activado=1 )
			begin
			 set @mens='El servidor publico no se ecuentra registrado, cedula de ciudadania: ' + @cedula
			end
	end
else
	begin
		if exists(SELECT dbo.VStbdiaslab.dlab_fecha FROM  dbo.VStbdiaslab WHERE(dbo.VStbdiaslab.emp_cedula = @cedula) AND (dbo.VStbdiaslab.dlab_fecha = @fecha) AND (dbo.VStbdiaslab.dlab_activado = 1))
		begin
			 set @mens='El servidor publico: ' + @cedula + ' ya registro subsistencia en la fecha: ' + cast(@fecha as nvarchar(20))
		end
	end
	select @mens as mens
go

