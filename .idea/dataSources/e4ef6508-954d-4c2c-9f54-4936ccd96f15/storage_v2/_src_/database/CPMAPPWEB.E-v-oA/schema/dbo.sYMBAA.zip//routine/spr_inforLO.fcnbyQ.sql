CREATE procedure spr_inforLO
@inf_codigo int
as
SELECT     dbo.VStbinforme.inf_codigo, dbo.wftbdepartamento.dep_nombre, dbo.VStbinforme.inf_fecha, dbo.VStbinforme.inf_rcedula, dbo.VStbinforme.inf_rnombre, 
                      CPMOOPP.dbo.optbfrente.fre_nombre, CPMOOPP.dbo.optbcanton.can_nombre, CPMOOPP.dbo.optbparroquia.par_nombre, CPMOOPP.dbo.optbfrente.fre_lugar, 
                      dbo.VStbinforme.inf_anio, dbo.VStbinforme.inf_mes, dbo.VStbinforme.inf_quincena, dbo.VStbinforme.inf_observa, dbo.wftbusuario.usr_apellido, 
                      dbo.wftbusuario.usr_nombre, dbo.VStbdatGene.emp_cedula, dbo.VStbdatGene.emp_nombre, dbo.VStbdatGene.emp_cargo, ISNULL(dbo.VStbdatGene.maq_descripcion,
                       N'-') AS maq_descripcion, ISNULL(dbo.VStbdatGene.maq_placa, N'-') AS maq_placa, dbo.VStbdiaslab.dlab_fecha, dbo.VStbdiaslab.dlab_tipo, 
                      dbo.VStbdiaslab.dlab_programado
FROM         dbo.VStbinforme INNER JOIN
                      dbo.VStbdatGene ON dbo.VStbinforme.inf_codigo = dbo.VStbdatGene.inf_codigo INNER JOIN
                      dbo.wftbdepartamento ON dbo.VStbinforme.dep_codigo = dbo.wftbdepartamento.dep_codigo INNER JOIN
                      CPMOOPP.dbo.optbfrente ON CPMOOPP.dbo.optbfrente.fre_codigo = dbo.VStbinforme.fre_codigo INNER JOIN
                      CPMOOPP.dbo.optbcanton ON CPMOOPP.dbo.optbcanton.can_codigo = dbo.VStbinforme.can_codigo INNER JOIN
                      CPMOOPP.dbo.optbparroquia ON CPMOOPP.dbo.optbparroquia.par_codigo = dbo.VStbinforme.par_codigo INNER JOIN
                      dbo.wftbusuario ON dbo.VStbinforme.inf_usuario = dbo.wftbusuario.usr_codigo INNER JOIN
                      dbo.VStbdiaslab ON dbo.VStbdatGene.inf_codigo = dbo.VStbdiaslab.inf_codigo AND dbo.VStbdatGene.emp_cedula = dbo.VStbdiaslab.emp_cedula
WHERE     (dbo.VStbinforme.inf_codigo = @inf_codigo) AND (dbo.VStbdatGene.dag_activado = 1) AND (dbo.VStbdiaslab.dlab_activado = 1)
go

