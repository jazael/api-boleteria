CREATE PROCEDURE [dbo].[spi_menP]
	@men_para  tinyint,
	@men_fecha  smalldatetime,
	@cco_id smallint,
	@proc_id tinyint,
	@usr_codigo smallint
AS
declare @med_orden as nvarchar(10)
declare @med_factura as nvarchar(10)
declare @med_base as float
declare @cod_item as int

update RSBtbparametro set @cod_item=cod_item+1, cod_item=cod_item+1 where anio=year(@men_fecha)

insert into RBStbcabmemo (mem_id, men_de, men_para, men_fecha, cco_id, proc_id, usr_codigo,men_activado)
values(@cod_item, 2, @men_para, @men_fecha, @cco_id, @proc_id, @usr_codigo,1 )

set @cod_item = (select men_sec from RBStbcabmemo where mem_id=@cod_item and men_fecha=@men_fecha)
declare detalle cursor for SELECT med_orden, med_factura, med_base FROM dbo.RBStbtemmen WHERE (usr_codigo = @usr_codigo)
OPEN detalle
FETCH NEXT FROM detalle
INTO @med_orden, @med_factura, @med_base
WHILE @@FETCH_STATUS = 0
BEGIN

		insert into RBStbdetmemo(men_sec,med_orden, med_factura, med_base, med_activado)
		values (@cod_item,@med_orden, @med_factura, @med_base,1)

FETCH NEXT FROM detalle
INTO @med_orden, @med_factura, @med_base
END	

DEALLOCATE detalle

delete dbo.RBStbtemmen  Where  (usr_codigo = @usr_codigo) 


select @cod_item as memo

go

