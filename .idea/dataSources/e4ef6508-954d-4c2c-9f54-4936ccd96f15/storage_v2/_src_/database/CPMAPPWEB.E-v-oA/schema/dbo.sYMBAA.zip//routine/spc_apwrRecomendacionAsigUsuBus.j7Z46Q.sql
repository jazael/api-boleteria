Create Procedure spc_apwrRecomendacionAsigUsuBus
@rri_id numeric(18,0),
@rec_recomendacion  varchar(max)
AS

/*Declare @rri_id numeric(18,0)
Declare @rec_recomendacion  varchar(max)
Set @rri_id=2
Set @rec_recomendacion='Ordenamiento Territorial' */

SELECT rec.rec_id, rin.rri_Id, rin.rri_ninforme, rec.rec_fechaini, rec.rec_fechafin, rec.rec_recomendacion 
FROM RRItbrecomendacion AS rec INNER JOIN RItbinforme AS rin ON rec.rri_id = rin.rri_Id
WHERE rec.rec_recomendacion Like '%'+@rec_recomendacion+'%' and (rec.rec_activado = 1) and rin.rri_id=@rri_id ORDER BY rec.rec_fechaini
go

