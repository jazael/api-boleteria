CREATE PROCEDURE [dbo].[spc_menP]
	@cad_codigo int,
	@cod_usr as smallint,
	@host nchar(20),
	@adress nchar(20)

AS
exec spi_auditoriaP @cod_usr,'spc_menP','Impresión de Memo Pago',@host ,@adress
SELECT           dbo.RBStbcabmemo.mem_id,RBStbdepara_1.dpa_detalle, RBStbdepara_1.dpa_departamento,
                          (SELECT     dpa_detalle
                            FROM          dbo.RBStbdepara
                            WHERE      (dpa_id = dbo.RBStbcabmemo.men_de)) AS dpa_para,
                          (SELECT     dpa_departamento
                            FROM          dbo.RBStbdepara AS RBStbdepara_2
                            WHERE      (dpa_id = dbo.RBStbcabmemo.men_de)) AS dpa_cargo, dbo.RBStbcabmemo.men_fecha, dbo.RBStbproced.proc_descrip, 
                      dbo.RBStbccomer.cco_descripcion, dbo.RBStbdetmemo.med_orden, dbo.RBStbdetmemo.med_factura, dbo.RBStbdetmemo.med_base, 
                      dbo.wftbusuario.usr_user
FROM         dbo.RBStbcabmemo INNER JOIN
                      dbo.RBStbdetmemo ON dbo.RBStbcabmemo.men_sec = dbo.RBStbdetmemo.men_sec INNER JOIN
                      dbo.RBStbproced ON dbo.RBStbcabmemo.proc_id = dbo.RBStbproced.proc_id INNER JOIN
                      dbo.RBStbccomer ON dbo.RBStbcabmemo.cco_id = dbo.RBStbccomer.cco_id INNER JOIN
                      dbo.RBStbdepara AS RBStbdepara_1 ON dbo.RBStbcabmemo.men_para = RBStbdepara_1.dpa_id INNER JOIN
                      dbo.wftbusuario ON dbo.RBStbcabmemo.usr_codigo = dbo.wftbusuario.usr_codigo
WHERE     (dbo.RBStbdetmemo.men_sec = @cad_codigo)
go

