CREATE PROCEDURE [dbo].[spe_pacdepf]
@pan_anio smallint,
@cod_usr as smallint,
@dep_codigo as smallint
AS
SELECT    dbo.RBStbpacanu.pan_anio as Año, dbo.RBStbpartidas.par_partida as Partida, dbo.RBStbpacanu.codigo_cl_inter as  Codigo_CPC, dbo.RBStbtipcompra.tic_descripcion as Tipo_de_Compra, 
                      dbo.RBStbpacanu.pan_deprod as Detalle, dbo.RBStbpacanu.pan_cantidad as Cantidad, 
                      CASE WHEN dbo.RBStbpacanu.pan_tipg = 'GC' THEN dbo.RBStbpacanu.pan_costo ELSE dbo.RBStbpacanu.pan_costo END AS Costo, dbo.RBStbmedida.med_descripcion as Medida, 
                      CASE WHEN dbo.RBStbpacanu.pan_c1 = 1 THEN 'S' ELSE '' END AS Cuatrimestre1, CASE WHEN dbo.RBStbpacanu.pan_c2 = 1 THEN 'S' ELSE '' END AS Cuatrimestre2, 
                      CASE WHEN dbo.RBStbpacanu.pan_c3 = 1 THEN 'S' ELSE '' END AS Cuatrimestre3, dbo.RBStbpacanu.pan_tipg as Tipo_Gasto
FROM         dbo.RBStbpacanu INNER JOIN
                      dbo.RBStbtipcompra ON dbo.RBStbpacanu.tic_codigo = dbo.RBStbtipcompra.tic_codigo INNER JOIN
                      dbo.RBStbmedida ON dbo.RBStbpacanu.med_codigo = dbo.RBStbmedida.med_codigo INNER JOIN
                      dbo.RBStbpartidas ON dbo.RBStbpacanu.par_codigo = dbo.RBStbpartidas.par_codigo INNER JOIN
                      dbo.wftbdepartamento ON dbo.RBStbpacanu.dep_codigo = dbo.wftbdepartamento.dep_codigo
WHERE     (dbo.RBStbpacanu.pan_activado = 1) AND (dbo.RBStbpacanu.pan_anio = @pan_anio)  AND 
                      (dbo.RBStbpacanu.dep_codigo = @dep_codigo)
ORDER BY dbo.RBStbpacanu.pan_tipg, dbo.RBStbpacanu.pan_deprod
exec spi_auditoriaP @cod_usr,'spe_pacdepf','exportacion de PAC','' ,''
go

