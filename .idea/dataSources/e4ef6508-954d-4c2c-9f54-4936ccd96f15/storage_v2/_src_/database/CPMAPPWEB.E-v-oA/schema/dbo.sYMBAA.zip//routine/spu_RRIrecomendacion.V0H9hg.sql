CREATE PROCEDURE spu_RRIrecomendacion
@rec_id numeric(18,0),
@rri_id numeric(18,0),
@rec_descripanalisis ntext,
@rec_numrecomendacion Varchar(8),
@rec_fechaini smalldatetime,
@rec_fechafin smalldatetime,
@rec_recomendacion ntext,
@rec_activado bit
AS
Update RRItbrecomendacion set
rec_descripanalisis=@rec_descripanalisis,
rec_numrecomendacion=@rec_numrecomendacion,
rec_fechaini=@rec_fechaini,
rec_fechafin=@rec_fechafin,
rec_recomendacion=@rec_recomendacion,
rec_activado=@rec_activado
where rec_id=@rec_id


Delete RRDtbserdir where rec_id=@rec_id
Delete RRDtbserres where rec_id=@rec_id

Declare @car_codigo smallint
--declare RRDtbserdir cursor for SELECT rri_id,emp_codigo from RRDtbserdirtemp sdt where rri_id=@rri_id
declare RRDtbserdir cursor for SELECT rri_id,car_codigo from RRDtbserdirtemp sdt where rri_id=@rri_id
OPEN RRDtbserdir
FETCH NEXT FROM RRDtbserdir
INTO @rri_id,@car_codigo

WHILE @@FETCH_STATUS = 0
BEGIN
insert into rrdtbserdir(rec_id,car_codigo)
Values(@rec_id,@car_codigo)
delete RRDtbserdirtemp where rri_id=@rri_id and car_codigo=@car_codigo
FETCH NEXT FROM RRDtbserdir
INTO @rri_id,@car_codigo
END   
CLOSE RRDtbserdir
DEALLOCATE RRDtbserdir
--------------------------------------
------------------------------------
Declare @emp_codigo smallint
declare RRDtbserres cursor for SELECT rri_id,emp_codigo from RRDtbserrestemp where rri_id=@rri_id
OPEN RRDtbserres
FETCH NEXT FROM RRDtbserres
INTO @rri_id,@emp_codigo

WHILE @@FETCH_STATUS = 0
BEGIN
insert into rrdtbserres(rec_id,emp_codigo)
Values(@rec_id,@emp_codigo)
delete RRDtbserrestemp where rri_id=@rri_id and emp_codigo=@emp_codigo
FETCH NEXT FROM RRDtbserres
INTO @rri_id,@emp_codigo
END
CLOSE RRDtbserres
DEALLOCATE RRDtbserres
go

