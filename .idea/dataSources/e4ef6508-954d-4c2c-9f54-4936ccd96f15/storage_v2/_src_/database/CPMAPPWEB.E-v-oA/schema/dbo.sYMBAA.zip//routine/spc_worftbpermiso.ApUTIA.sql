
CREATE PROCEDURE [dbo].[spc_worftbpermiso]
@usr_user	varchar(50),
@usr_password varchar(50),
@usr_existe bit output,
@usr_nombre varchar(100) output,
@usr_codigo smallint output,
@name_departamento varchar(50) output,
@dep_codigo int output,
@tusu_codigo int output
AS
BEGIN
SELECT   @usr_existe = COUNT(*) ,@usr_nombre= wftbusuario.usr_nombre + ' ' + wftbusuario.usr_apellido , @usr_codigo=wftbusuario.usr_codigo,@tusu_codigo=wftbusuario.tusu_codigo,@name_departamento = wftbdepartamento.dep_nombre,@dep_codigo = wftbdepartamento.dep_codigo
FROM         wftbusuario INNER JOIN
                      wftbdepartamento ON wftbusuario.dep_codigo = wftbdepartamento.dep_codigo
WHERE     (wftbusuario.usr_user = @usr_user) AND (wftbusuario.usr_password = @usr_password)
GROUP BY wftbusuario.usr_nombre, wftbusuario.usr_apellido, wftbusuario.usr_codigo,tusu_codigo, wftbdepartamento.dep_nombre,wftbdepartamento.dep_codigo
exec spi_auditoriaP @usr_codigo,'spc_worftbpermiso','Inicio de Sesión',' - ' ,' - '
END


go

