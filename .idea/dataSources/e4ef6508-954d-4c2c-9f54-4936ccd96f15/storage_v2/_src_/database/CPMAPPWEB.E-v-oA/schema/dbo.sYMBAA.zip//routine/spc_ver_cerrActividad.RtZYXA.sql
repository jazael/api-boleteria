
Create Procedure spc_ver_cerrActividad
@rar_Id numeric(18,0)
AS
Select count(rar_id) rar_id from RARTBActividad Where rar_id=@rar_Id and rar_estado=0 and rar_motivo='' and rar_terminada=0
go

