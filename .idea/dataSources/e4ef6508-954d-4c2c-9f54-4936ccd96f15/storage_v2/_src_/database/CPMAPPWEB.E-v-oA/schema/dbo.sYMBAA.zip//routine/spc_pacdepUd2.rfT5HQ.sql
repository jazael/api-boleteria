
CREATE PROCEDURE [dbo].[spc_pacdepUd2]
@dep_codigo int,
@opcion int
AS
declare @anio smallint
set @anio = (select an_valor from RBStbanios where an_activado=1)
	SELECT     dbo.RBStbpacanu.pan_id, dbo.RBStbtipcompra.tic_descripcion, dbo.RBStbpacanu.codigo_cl_inter, substring(dbo.RBStbpac.nombre_cl_inter,1,200) as nombre_cl_inter, dbo.RBStbpacanu.pan_deprod, 
									  dbo.RBStbpacanu.pan_cantidad,dbo.RBStbpacanu.pan_costo, (dbo.RBStbpacanu.pan_cantidad*dbo.RBStbpacanu.pan_costo) as total,dbo.RBStbpacanu.pan_tipg
				FROM         dbo.RBStbpacanu INNER JOIN
									  dbo.RBStbtipcompra ON dbo.RBStbpacanu.tic_codigo = dbo.RBStbtipcompra.tic_codigo INNER JOIN
									  dbo.RBStbpac ON dbo.RBStbpacanu.secuencia = dbo.RBStbpac.secuencia
				WHERE     (dbo.RBStbpacanu.pan_activado = 1) AND (dbo.RBStbpacanu.pan_valid = @opcion) AND (dbo.RBStbpacanu.dep_codigo = @dep_codigo)  AND 
									  (dbo.RBStbpacanu.pan_anio = @anio)
				order by dbo.RBStbpacanu.pan_deprod

go

