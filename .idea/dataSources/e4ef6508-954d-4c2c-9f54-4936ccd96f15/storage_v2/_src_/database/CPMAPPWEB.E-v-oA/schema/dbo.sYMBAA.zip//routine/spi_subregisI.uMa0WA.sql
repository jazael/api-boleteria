CREATE procedure [dbo].[spi_subregisI]
@dep_codigo	smallint,
@inf_fecha	smalldatetime,
@inf_rcedula	nchar(10),
@inf_rnombre	nchar(80),
@fre_codigo	int,
@inf_anio	smallint,
@inf_mes	tinyint,
@inf_quincena	tinyint,
@inf_observa	ntext,
@inf_usuario	smallint
as
declare @inf_codigo as int
declare @can_codigo	as smallint
declare @par_codigo	as smallint
set @can_codigo= (select can_codigo from CPMOOPP.dbo.optbfrente where fre_codigo=@fre_codigo)
set @par_codigo= (select par_codigo from CPMOOPP.dbo.optbfrente where fre_codigo=@fre_codigo)
update Rsbtbparametro set  @inf_codigo= inf_codigo+1, inf_codigo=inf_codigo+1 where anio='2011' 
insert VSTBinforme(inf_codigo,dep_codigo,inf_fecha,inf_rcedula,inf_rnombre,fre_codigo,can_codigo,par_codigo,inf_anio,inf_mes,
					inf_quincena,inf_observa,inf_usuario,inf_activado)
					Values(@inf_codigo,@dep_codigo,@inf_fecha,@inf_rcedula,@inf_rnombre,@fre_codigo,@can_codigo,@par_codigo,@inf_anio,@inf_mes,
					@inf_quincena,@inf_observa,@inf_usuario,1)

select @inf_codigo as inf_codigo

