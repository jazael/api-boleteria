

CREATE procedure [dbo].[spi_regdocex]
@tra_control	varchar(30),
@tra_origen	varchar(80),
@tra_tdoc	tinyint,
@tra_asunto	varchar(200),
@can_codigo	smallint,
@tra_fecha	smalldatetime,
@usr_codigo smallint,
@doc_pdf	image	
as

declare @tra_exid as int
update RSBtbparametro set @tra_exid=doc_codigo+1, doc_codigo=doc_codigo+1 where anio=year(getdate())

insert cdtbtramitex(tra_exid,tra_control,tra_origen,tra_tdoc,tra_asunto,can_codigo,tra_fecha,usr_codigo,tra_activado,tra_fechafx)
			values(@tra_exid,@tra_control,@tra_origen,@tra_tdoc,@tra_asunto,@can_codigo,@tra_fecha,@usr_codigo,1,getdate())
insert cdtbdocumento(tra_id,doc_pdf,doc_rec,doc_activado,doc_tipe)
		values(@tra_exid,@doc_pdf,0,1,0)


go

