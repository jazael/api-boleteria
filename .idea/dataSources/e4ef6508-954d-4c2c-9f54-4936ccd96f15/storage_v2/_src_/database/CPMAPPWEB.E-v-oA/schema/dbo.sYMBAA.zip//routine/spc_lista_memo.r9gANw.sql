
create PROCEDURE [dbo].[spc_lista_memo]
@usr_codigo as smallint,
@cad_fecha as datetime,
@cad_fecha_hasta as datetime,
@activado as bit
	
AS
SELECT  dbo.RBStbcabmemo.men_sec, dbo.RBStbcabmemo.mem_id, dbo.RBStbccomer.cco_descripcion,
                          (SELECT     dpa_detalle
                            FROM          dbo.RBStbdepara
                            WHERE      (dpa_id = dbo.RBStbcabmemo.men_para)) AS dpa_detalle, dbo.RBStbcabmemo.men_fecha
FROM         dbo.RBStbcabmemo INNER JOIN
                      dbo.RBStbccomer ON dbo.RBStbcabmemo.cco_id = dbo.RBStbccomer.cco_id
WHERE     (dbo.RBStbcabmemo.men_fecha BETWEEN @cad_fecha AND @cad_fecha_hasta) AND (dbo.RBStbcabmemo.men_activado = @activado)
ORDER BY dbo.RBStbcabmemo.men_fecha
go

