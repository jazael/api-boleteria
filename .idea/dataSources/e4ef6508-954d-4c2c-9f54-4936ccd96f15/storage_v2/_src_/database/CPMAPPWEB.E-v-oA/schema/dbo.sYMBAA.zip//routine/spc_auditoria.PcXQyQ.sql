CREATE procedure [dbo].[spc_auditoria]
@usr_codigo smallint,
@tipo tinyint,
@desde nvarchar(21),
@hasta nvarchar(21),
@cod_usr smallint,
@host nchar(20),
@adress nchar(20)
as
exec spi_auditoriaP @cod_usr,'spc_auditoria','Auditoria',@host ,@adress
if @tipo=1
begin 
	SELECT     Tabla,Tipo, Usuario_Ba AS Usuario_Base,clave_ID, campo_nombre AS Campo, valor_ant, valor_nuev AS valor_nuevo, fecha
	FROM         dbo.wftbauditoriaT
	where fecha between @desde and @hasta

end
else
begin
	
		SELECT     dbo.wftbauditoriaP.aud_proceso, dbo.wftbauditoriaP.aud_opcion, dbo.wftbauditoriaP.aud_fecha,dbo.wftbauditoriaP.aud_host, dbo.wftbusuario.usr_nombre AS usuario
		FROM         dbo.wftbauditoriaP INNER JOIN
                      dbo.wftbusuario ON dbo.wftbauditoriaP.aud_usuario = dbo.wftbusuario.usr_codigo
		where aud_fecha between @desde and @hasta and  dbo.wftbusuario.usr_codigo=@usr_codigo

end
go

