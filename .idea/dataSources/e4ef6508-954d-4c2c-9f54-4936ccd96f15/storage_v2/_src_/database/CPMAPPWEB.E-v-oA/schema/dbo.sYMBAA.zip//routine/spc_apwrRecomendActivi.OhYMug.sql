CREATE PROCEDURE spc_apwrRecomendActivi--Solo muestra las recomendaciones que tengan actividades registradas
@rri_id numeric(18,0)
AS

Select distinct rec.rec_Id,rec_recomendacion from RRItbrecomendacion AS rec inner join RARTBActividad AS rac
on rec.rec_id=rac.rec_id Where rac.rri_id=@rri_id
go

