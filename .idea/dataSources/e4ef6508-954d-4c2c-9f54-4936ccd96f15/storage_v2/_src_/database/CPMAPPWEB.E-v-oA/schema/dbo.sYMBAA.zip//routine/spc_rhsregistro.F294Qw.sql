create procedure [dbo].[spc_rhsregistro]
@reg_cedula varchar(10),
@opt as tinyint
as
declare @bit as tinyint
set @bit=0
if @opt=1 begin
	if not exists(select sol_cedula from DHSRegistro where sol_cedula=@reg_cedula and sol_estado=1 and sol_activado=1)
	begin 
	set @bit=1
	end end
	else
	begin
		if not exists(select sol_cedulaB from DHSRegistro  where sol_cedulaB=@reg_cedula and sol_estado=1 and sol_activado=1)
		begin 
		set @bit=2
		end
	end
select @bit as bit
go

