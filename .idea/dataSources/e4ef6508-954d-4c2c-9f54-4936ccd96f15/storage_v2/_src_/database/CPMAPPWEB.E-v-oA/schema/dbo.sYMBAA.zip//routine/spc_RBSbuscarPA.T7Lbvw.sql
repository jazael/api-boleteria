


CREATE procedure [dbo].[spc_RBSbuscarPA]
@buscar nvarchar(50),
@opcion tinyint 
as
if substring(@buscar,1,1)='1' or substring(@buscar,1,1)='2'or substring(@buscar,1,1)='3'or substring(@buscar,1,1)='4'or substring(@buscar,1,1)='5'or substring(@buscar,1,1)='6'or substring(@buscar,1,1)='7'or substring(@buscar,1,1)='8' or substring(@buscar,1,1)='9' or substring(@buscar,1,1)='0' 
begin
			set @opcion=(select dep_depende from wftbdepartamento where dep_codigo=@opcion)
			SELECT    pan_id as secuencia, codigo_cl_inter, pan_id AS codigo_cl_inter_padre, pan_deprod AS nombre_cl_inter
			FROM         dbo.RBStbpacanu
			WHERE     (pan_activado = 1) AND (pan_anio = 2016) AND (codigo_cl_inter LIKE '%' + RTRIM(@buscar) + '%') AND (pan_valid = 1) AND (dep_codigo = @opcion)
			ORDER BY codigo_cl_inter
end
else
begin
			set @opcion=(select dep_depende from wftbdepartamento where dep_codigo=@opcion)
			SELECT    pan_id as secuencia, codigo_cl_inter, pan_id AS codigo_cl_inter_padre, pan_deprod AS nombre_cl_inter
			FROM         dbo.RBStbpacanu
			WHERE     (pan_activado = 1) AND (pan_anio = 2016) AND (pan_deprod LIKE '%' + RTRIM(@buscar) + '%') AND (pan_valid = 1) AND (dep_codigo = @opcion)
			ORDER BY codigo_cl_inter
end


go

