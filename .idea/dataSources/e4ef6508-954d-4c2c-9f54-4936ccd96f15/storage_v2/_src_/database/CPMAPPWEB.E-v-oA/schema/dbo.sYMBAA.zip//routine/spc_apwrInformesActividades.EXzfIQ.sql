CREATE PROCEDURE spc_apwrInformesActividades--Solo muestra los informes que tengan actividades registradas
AS

Select distinct rin.rri_Id,rri_ninforme from RItbinforme AS rin inner join RARTBActividad AS rac
on rin.rri_Id=rac.rri_id
go

