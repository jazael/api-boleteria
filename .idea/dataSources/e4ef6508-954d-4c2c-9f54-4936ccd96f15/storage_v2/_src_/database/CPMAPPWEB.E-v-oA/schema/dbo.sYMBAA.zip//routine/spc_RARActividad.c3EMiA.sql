
CREATE PROCEDURE spc_RARActividad
@rri_id numeric(18,0),
@rec_id numeric(18,0),
@usr_codigo smallint
AS
--Select * from dbo.RARTBActividad where rri_id=@rri_id and rec_id=@rec_id and usr_codigo=@usr_codigo

SELECT rar_Id,rri_id,rec_id,usr_codigo,rar_fechaingreso,rar_fechaini,rar_fechafin,rar_estrategia,rar_actividad,
rar_estado,CASE WHEN rar_estado='' then 'NO' else 'SI' end rar_motivo,rar_terminada,rar_activado
FROM RARTBActividad where rri_id=@rri_id and rec_id=@rec_id and usr_codigo=@usr_codigo

