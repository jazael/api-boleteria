Create Procedure spc_apwInfRec
@rec_id numeric(18,0)
AS

SELECT rec.rec_id, rin.rri_Id, rin.rri_ninforme, rri_alcance, rri_faprobacion,rec.rec_fechaini, rec.rec_fechafin, rec.rec_recomendacion,rec_activado
FROM RRItbrecomendacion AS rec INNER JOIN RItbinforme AS rin ON rec.rri_id = rin.rri_Id WHERE rec.rec_id=@rec_id and rec_activado=1
go

