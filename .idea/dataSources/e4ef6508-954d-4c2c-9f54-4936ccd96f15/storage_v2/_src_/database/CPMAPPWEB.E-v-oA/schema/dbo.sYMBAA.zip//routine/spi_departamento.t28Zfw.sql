CREATE procedure [dbo].[spi_departamento]
@usr_codigo smallint,
@dep_nombre varchar(50),
@dep_abre nchar(10),
@dep_depende tinyint,
@dep_rip nvarchar(20),
@dep_activado bit,
@host nchar(20),
@adress nchar(20)

as
declare @dep_codigo as tinyint
declare @bit as tinyint
set @bit=0
set @dep_codigo=Isnull((select max(dep_codigo) from dbo.wftbdepartamento),0)+1

if not exists(select dep_codigo from wftbdepartamento where dep_nombre=@dep_nombre)
begin
	insert wftbdepartamento(dep_codigo,dep_nombre,dep_abre,dep_depende,dep_rip,dep_activado)
			values(@dep_codigo,@dep_nombre,@dep_abre,@dep_depende,@dep_rip,@dep_activado)
exec spi_auditoriaP @usr_codigo,'spi_departamento','Ingreso de Facultad',@host ,@adress

end
else
begin
set @bit =1
end 
select @bit as bit
go

