create PROCEDURE [dbo].[spc_CPPregeli]
@reg_cedula	nchar(10)
AS

if exists(select * from CPPRegistro where reg_cedula=@reg_cedula and reg_activado=1) 
	begin
	update CPPRegistro set
	reg_activado=0
	 where reg_cedula=@reg_cedula
		select dato='SU REGISTRO FUE ELIMINADO'
	end
else
	begin
		select dato='NO EXISTEN DATOS REGISTRADOS'
	end
go

