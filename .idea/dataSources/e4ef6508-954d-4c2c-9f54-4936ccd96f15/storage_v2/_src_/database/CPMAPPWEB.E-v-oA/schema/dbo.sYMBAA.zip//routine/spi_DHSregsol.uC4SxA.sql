
CREATE procedure [dbo].[spi_DHSregsol]
@can_codigo smallint,
@par_codigo smallint,
@sol_recinto nvarchar(80),
@sol_cedula nchar(10),
@sol_nombre nvarchar(80),
@sol_apellido	nvarchar(80),
@sol_email	nvarchar(20),
@sol_telefono	nvarchar(20),
@sol_cedulaB	nchar(10),
@sol_nombreB	nvarchar(80),
@sol_apellidoB	nvarchar(80),
@can_codigoB smallint,
@par_codigoB smallint,
@sol_recintoB nvarchar(80),
@sol_detalleR	ntext,
@doc_extension1 as nvarchar(10),
@doc_extension2 as nvarchar(10),
@doc_extension3 as nvarchar(10),
@reg_csol	image,	
@reg_bene	image,	
@reg_hvida	image	
as
declare @sol_codpmt as int
declare @sol_codpro as nvarchar(20)
declare @sol_codpmtc as nvarchar(10)
update RSBtbparametro set @sol_codpmt=sol_codigo+1,sol_codigo= sol_codigo+1 where anio='2019'
set  @sol_codpmtc='000000'+CAST( @sol_codpmt as char(5))
set @sol_codpro= 'DH-SAC-' + CAST( year(getdate()) as char(4)) + '-'+ right(  Ltrim(Rtrim(@sol_codpmtc)),5) 
insert DHSRegistro(sol_codpro,sol_codpmt,can_codigo,par_codigo,sol_recinto,sol_cedula,sol_nombre,sol_apellido,sol_email,sol_telefono,
					sol_cedulaB,sol_nombreB,sol_apellidoB,can_codigoB,par_codigoB,sol_recintoB,sol_detalleR,sol_fecha,sol_activado,sol_estado)
			values(@sol_codpro,@sol_codpmt,@can_codigo,@par_codigo,@sol_recinto,@sol_cedula,@sol_nombre,@sol_apellido,@sol_email,@sol_telefono,
					@sol_cedulaB,@sol_nombreB,@sol_apellidoB,@can_codigoB,@par_codigoB,@sol_recintoB,@sol_detalleR,GETDATE(),1,1)

insert DHSDocumentos(sol_codpmt,doc_archivo,doc_activado,doc_tipo,doc_descripcion,doc_extension)
		values(@sol_codpmt,@reg_csol,1,1,'CEDULA DEL SOLICITANTE',@doc_extension1)

		
insert DHSDocumentos(sol_codpmt,doc_archivo,doc_activado,doc_tipo,doc_descripcion,doc_extension)
		values(@sol_codpmt,@reg_csol,1,2,'CEDULA DEL BENEFICIARIO',@doc_extension2)
		
insert DHSDocumentos(sol_codpmt,doc_archivo,doc_activado,doc_tipo,doc_descripcion,doc_extension)
		values(@sol_codpmt,@reg_csol,1,3,'OTROS DOCUMENTOS',@doc_extension3)
go

