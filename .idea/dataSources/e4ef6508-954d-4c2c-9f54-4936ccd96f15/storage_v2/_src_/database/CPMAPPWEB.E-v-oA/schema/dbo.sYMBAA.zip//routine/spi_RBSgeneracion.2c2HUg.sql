CREATE PROCEDURE [dbo].[spi_RBSgeneracion]
	
	@cad_fecha as datetime,
	@cad_observacion as nvarchar(1000),
	@dep_codigo as tinyint,
	@usr_codigo as smallint,
	@host nchar(20),
	@adress nchar(20)
	
AS

declare @Num_orden as int
declare @det_pac as int
declare @cad_codigo as int
declare @ite_codigo as varchar(50)
declare @det_cantidad as smallmoney
declare @ite_detalle as nchar(200)
declare @ite_secuencia as smallint
exec spi_auditoriaP @usr_codigo,'spi_RBSgeneracion','Generacion de Ordenes',@host ,@adress


update RSBtbparametro set @cad_codigo=Numero_orden+1, Numero_orden=Numero_orden+1 where anio=year(@cad_fecha)






insert into RBStbcadord (cad_codigo, cad_fecha, cad_fecha_trx, cad_observacion, dep_codigo, usr_codigo, cad_activado)
values(@cad_codigo,@cad_fecha, getdate(), @cad_observacion, @dep_codigo, @usr_codigo, 1 )


declare detalle cursor for SELECT     TOP (100) PERCENT det_cantidad, ite_secuencia, ite_detalle,ite_codigo,det_pac
FROM         dbo.RBStbdetord_temporal
WHERE     (det_activado = 1) AND (usr_codigo = @usr_codigo)
OPEN detalle
FETCH NEXT FROM detalle
INTO @det_cantidad , @ite_secuencia,@ite_detalle,@ite_codigo,@det_pac
WHILE @@FETCH_STATUS = 0
BEGIN

		insert into RBStbdetord(cad_codigo,ite_secuencia, det_detalle, ite_codigo, det_cantidad, det_activado,det_pac)
		values (@cad_codigo,@ite_secuencia, @ite_detalle,@ite_codigo, @det_cantidad, 1,@det_pac)

FETCH NEXT FROM detalle
INTO @det_cantidad , @ite_secuencia,@ite_detalle,@ite_codigo,@det_pac
END	

DEALLOCATE detalle

delete RBStbdetord_temporal  Where (det_activado = 1) and (usr_codigo = @usr_codigo) 


select @cad_codigo as cad_codigo

