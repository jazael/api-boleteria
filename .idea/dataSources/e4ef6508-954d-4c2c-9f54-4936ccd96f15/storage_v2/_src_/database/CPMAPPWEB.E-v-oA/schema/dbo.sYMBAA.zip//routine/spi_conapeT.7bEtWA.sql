
create procedure [dbo].[spi_conapeT]
@reg_id	numeric(18, 0),
@tpe_codigo tinyint,
@ape_comenta nvarchar(300)
as
insert CMOtbapela(reg_id,ape_comenta,tpe_codigo,ape_fecha)
		values(@reg_id,@ape_comenta,@tpe_codigo,getdate())

go

